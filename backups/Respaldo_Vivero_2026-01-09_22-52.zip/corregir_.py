from app import create_app
from app.extensions import db
from sqlalchemy import text

app = create_app()

with app.app_context():
    try:
        # Comando SQL para agregar la columna manualmente
        print("Intentando agregar la columna 'proposito'...")
        
        # Sentencia SQL para MySQL
        sql = text("ALTER TABLE lote_produccion ADD COLUMN proposito VARCHAR(20) DEFAULT 'Venta Plantula'")
        
        db.session.execute(sql)
        db.session.commit()
        
        print("✅ ¡Éxito! Columna 'proposito' agregada correctamente.")
        
    except Exception as e:
        # Si falla, es probable que ya exista o haya otro problema
        print(f"⚠️ Nota: {e}")
        print("Si dice 'Duplicate column', significa que ya estaba creada.")