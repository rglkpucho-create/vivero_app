from app import create_app
from app.extensions import db
from sqlalchemy import text

app = create_app()

def migrar_final():
    with app.app_context():
        print("\n🔧 Ajustando base de datos para el nuevo modelo de inventario...")
        
        # Usamos bloques try/except separados para asegurar que todos los cambios se intenten
        with db.engine.connect() as conn:
            
            # 1. Agregar campo de imagen a insumos (SOLUCIÓN A TU ERROR ACTUAL)
            try:
                conn.execute(text("ALTER TABLE insumos ADD COLUMN imagen_url VARCHAR(255)"))
                print("✅ ÉXITO: Columna 'imagen_url' agregada a tabla 'insumos'.")
            except Exception as e:
                if "Duplicate column" in str(e) or "1060" in str(e):
                    print("ℹ️ La columna 'imagen_url' ya existía.")
                else:
                    print(f"⚠️ Alerta (imagen_url): {e}")

            # 2. Agregar sede_id a pedidos_compra (Para la lógica de destinos)
            try:
                conn.execute(text("ALTER TABLE pedidos_compra ADD COLUMN sede_id INTEGER REFERENCES sedes(id)"))
                print("✅ ÉXITO: Columna 'sede_id' agregada a tabla 'pedidos_compra'.")
            except Exception as e:
                if "Duplicate column" in str(e) or "1060" in str(e):
                    print("ℹ️ La columna 'sede_id' ya existía en pedidos.")
                else:
                    print(f"⚠️ Alerta (sede_id): {e}")

            conn.commit()
            print("\n🚀 Base de datos actualizada correctamente.")

if __name__ == "__main__":
    migrar_final()