import os
from werkzeug.utils import secure_filename
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, current_app
from flask_login import login_user, logout_user, login_required, current_user
from sqlalchemy import or_
from .models import (
    Usuario, Rol, Proveedor, Insumo, UnidadMedida, 
    PedidoCompra, DetallePedidoCompra, LoteInsumo, MovimientoInventario,
    Especie, LoteProduccion, LaborCampo, ConsumoInsumo,
    Cliente, Venta, DetalleVenta, Sede
)
from .extensions import db
from datetime import datetime

main_bp = Blueprint('main', __name__)

# --- CONFIGURACIÓN DE SUBIDA DE IMÁGENES ---
def guardar_imagen(archivo, carpeta):
    if not archivo: return None
    filename = secure_filename(archivo.filename)
    # Nombre único usando timestamp para evitar duplicados
    nombre_unico = f"{int(datetime.now().timestamp())}_{filename}"
    
    # Ruta absoluta para guardar en el sistema de archivos
    path_folder = os.path.join(current_app.root_path, 'static', 'uploads', carpeta)
    os.makedirs(path_folder, exist_ok=True) # Crea la carpeta si no existe
    
    archivo.save(os.path.join(path_folder, nombre_unico))
    # Retorna la ruta relativa para guardar en la base de datos
    return f"uploads/{carpeta}/{nombre_unico}"

# ==================================================
# 1. RUTAS PÚBLICAS Y AUTENTICACIÓN
# ==================================================

@main_bp.route('/')
def home():
    return render_template('index.html')

@main_bp.route('/registro', methods=['GET', 'POST'])
def registro():
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))

    if not Rol.query.first():
        try:
            roles_iniciales = [Rol(nombre='Administrador'), Rol(nombre='Trabajador'), Rol(nombre='Agrónomo'), Rol(nombre='Vendedor')]
            db.session.add_all(roles_iniciales)
            db.session.commit()
        except: db.session.rollback()

    if request.method == 'POST':
        nombre = request.form.get('nombre')
        email = request.form.get('email')
        password = request.form.get('password')
        telefono = request.form.get('telefono')
        rol_nombre = request.form.get('rol') 

        if not nombre or not email or not password:
            flash('Por favor llena los campos obligatorios.', 'warning')
            return render_template('registro.html')

        if Usuario.query.filter_by(email=email).first():
            flash('El correo ya está registrado.', 'warning')
            return render_template('registro.html')

        rol_obj = Rol.query.filter_by(nombre=rol_nombre).first()
        if not rol_obj: rol_obj = Rol.query.filter_by(nombre='Trabajador').first()

        try:
            nuevo_usuario = Usuario(
                nombre_completo=nombre, email=email, telefono=telefono,
                rol_id=rol_obj.id if rol_obj else None, fecha_registro=datetime.utcnow()
            )
            nuevo_usuario.set_password(password)
            db.session.add(nuevo_usuario)
            db.session.commit()
            flash('¡Cuenta creada! Por favor inicia sesión.', 'success')
            return redirect(url_for('main.login'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al registrar: {e}', 'danger')

    try: roles = Rol.query.all()
    except: roles = []
    return render_template('registro.html', roles=roles)

@main_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated: return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = Usuario.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user)
            flash(f'Bienvenido, {user.nombre_completo}', 'success')
            return redirect(url_for('main.dashboard'))
        else:
            flash('Email o contraseña incorrectos.', 'danger')
    return render_template('login.html')

@main_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.home'))

@main_bp.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html',
                           datetime=datetime,
                           total_insumos=Insumo.query.count(),
                           total_proveedores=Proveedor.query.count(),
                           insumos_alerta=Insumo.query.filter(Insumo.cantidad_actual <= Insumo.stock_minimo).all(),
                           pedidos_pendientes=PedidoCompra.query.filter_by(estado='Solicitado').count(),
                           lotes_activos=LoteProduccion.query.filter_by(estado='En Crecimiento').count(),
                           ventas_mes=Venta.query.filter(Venta.fecha >= datetime.now().replace(day=1)).count(),
                           species=Especie.query.all(),
                           proveedores=Proveedor.query.order_by(Proveedor.razon_social).all(),
                           unidades=UnidadMedida.query.all())

# ==================================================
# 2. GESTIÓN DE TERCEROS (PROVEEDORES)
# ==================================================

@main_bp.route('/proveedores')
@login_required
def lista_proveedores():
    query_str = request.args.get('q', '').strip()
    es_ajax = request.args.get('ajax') == '1'
    
    query = Proveedor.query
    
    if query_str:
        query = query.filter(or_(
            Proveedor.razon_social.ilike(f'%{query_str}%'),
            Proveedor.nit_rut.ilike(f'%{query_str}%'),
            Proveedor.contacto_nombre.ilike(f'%{query_str}%')
        ))
    
    proveedores = query.order_by(Proveedor.razon_social).all()
    
    if es_ajax:
        return render_template('parciales/items_proveedores.html', proveedores=proveedores)
        
    return render_template('lista_proveedores.html', proveedores=proveedores, search_query=query_str)

@main_bp.route('/proveedor/nuevo', methods=['GET', 'POST'])
@main_bp.route('/proveedor/editar/<int:proveedor_id>', methods=['GET', 'POST'])
@login_required
def nuevo_proveedor(proveedor_id=None):
    proveedor = Proveedor.query.get_or_404(proveedor_id) if proveedor_id else None
    if request.method == 'POST':
        razon_social = request.form.get('razon_social')
        if not razon_social:
            flash('La Razón Social es obligatoria.', 'warning')
            return render_template('nuevo_proveedor.html', proveedor=proveedor)
        
        try:
            if proveedor:
                proveedor.razon_social = razon_social
                proveedor.nit_rut = request.form.get('nit_rut')
                proveedor.contacto_nombre = request.form.get('contacto_nombre')
                proveedor.telefono = request.form.get('telefono')
                proveedor.email = request.form.get('email')
                proveedor.direccion = request.form.get('direccion')
                flash('Proveedor actualizado.', 'success')
            else:
                nuevo = Proveedor(
                    razon_social=razon_social, nit_rut=request.form.get('nit_rut'),
                    contacto_nombre=request.form.get('contacto_nombre'), telefono=request.form.get('telefono'),
                    email=request.form.get('email'), direccion=request.form.get('direccion')
                )
                db.session.add(nuevo)
                flash('Proveedor registrado.', 'success')
            db.session.commit()
            return redirect(url_for('main.lista_proveedores'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al guardar: {e}', 'danger')
            return render_template('nuevo_proveedor.html', proveedor=proveedor)

    return render_template('nuevo_proveedor.html', proveedor=proveedor)

@main_bp.route('/proveedor/eliminar/<int:proveedor_id>', methods=['POST'])
@login_required
def eliminar_proveedor(proveedor_id):
    proveedor = Proveedor.query.get_or_404(proveedor_id)
    try:
        db.session.delete(proveedor)
        db.session.commit()
        flash('Proveedor eliminado.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar: {e}', 'danger')
    return redirect(url_for('main.lista_proveedores'))


# ==================================================
# 3. GESTIÓN DE INVENTARIOS (INSUMOS)
# ==================================================

@main_bp.route('/insumos')
@login_required
def lista_insumos():
    query_str = request.args.get('q', '').strip()
    mostrar_alertas = request.args.get('alertas') == '1' # Detectar filtro de alertas
    es_ajax = request.args.get('ajax') == '1'
    
    query = Insumo.query

    if query_str:
        query = query.filter(or_(
            Insumo.nombre.ilike(f'%{query_str}%'),
            Insumo.tipo.ilike(f'%{query_str}%')
        ))
    
    if mostrar_alertas:
        query = query.filter(Insumo.cantidad_actual <= Insumo.stock_minimo)

    insumos = query.all()
    
    if es_ajax:
        return render_template('parciales/items_insumos.html', insumos=insumos)

    return render_template('lista_insumos.html', insumos=insumos, search_query=query_str)

@main_bp.route('/insumo/nuevo', methods=['GET', 'POST'])
@main_bp.route('/insumo/editar/<int:insumo_id>', methods=['GET', 'POST'])
@login_required
def nuevo_insumo(insumo_id=None):
    insumo = Insumo.query.get_or_404(insumo_id) if insumo_id else None
    unidades = UnidadMedida.query.all()
    
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        tipo = request.form.get('tipo')
        unidad_id = request.form.get('unidad_id')
        stock_min = float(request.form.get('stock_minimo', 0))

        if not nombre:
            flash('El nombre es obligatorio.', 'warning')
            return render_template('nuevo_insumo.html', unidades=unidades, insumo=insumo)

        try:
            # Procesar Imagen
            imagen_path = None
            if 'imagen' in request.files:
                file = request.files['imagen']
                if file and file.filename != '':
                    imagen_path = guardar_imagen(file, 'insumos')

            if insumo:
                insumo.nombre = nombre
                insumo.tipo = tipo
                insumo.unidad_medida_id = int(unidad_id) if unidad_id else None
                insumo.stock_minimo = stock_min
                if imagen_path: insumo.imagen_url = imagen_path
                flash('Insumo actualizado correctamente.', 'success')
            else:
                nuevo = Insumo(
                    nombre=nombre, tipo=tipo,
                    unidad_medida_id=int(unidad_id) if unidad_id else None,
                    stock_minimo=stock_min,
                    cantidad_actual=0.0, 
                    costo_promedio=0.0,
                    imagen_url=imagen_path
                )
                db.session.add(nuevo)
                flash('Insumo creado correctamente.', 'success')
            
            db.session.commit()
            return redirect(url_for('main.lista_insumos'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al guardar insumo: {e}', 'danger')
            return render_template('nuevo_insumo.html', unidades=unidades, insumo=insumo)

    return render_template('nuevo_insumo.html', unidades=unidades, insumo=insumo)

@main_bp.route('/insumo/eliminar/<int:insumo_id>', methods=['POST'])
@login_required
def eliminar_insumo(insumo_id):
    insumo = Insumo.query.get_or_404(insumo_id)
    try:
        db.session.delete(insumo)
        db.session.commit()
        flash('Insumo eliminado.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar: {e}', 'danger')
    return redirect(url_for('main.lista_insumos'))


# ==================================================
# 4. GESTIÓN DE COMPRAS (PEDIDOS, FIFO Y AJAX)
# ==================================================

@main_bp.route('/compras')
@login_required
def lista_pedidos():
    # 1. Capturamos los filtros que vienen en la URL
    estado_arg = request.args.get('estado')
    proveedor_arg = request.args.get('proveedor_id')
    fecha_ini = request.args.get('fecha_inicio')
    fecha_fin = request.args.get('fecha_fin')

    # 2. Iniciamos la consulta base
    query = PedidoCompra.query

    # 3. Aplicamos filtros dinámicamente
    if estado_arg:
        # Asegúrate de que los strings coincidan exactamente con tu BD ('Solicitado', 'Recibido', etc.)
        query = query.filter(PedidoCompra.estado == estado_arg)

    if proveedor_arg and proveedor_arg.isdigit():
        query = query.filter(PedidoCompra.proveedor_id == int(proveedor_arg))

    if fecha_ini:
        try:
            fecha_dt = datetime.strptime(fecha_ini, '%Y-%m-%d').date()
            query = query.filter(PedidoCompra.fecha_solicitud >= fecha_dt)
        except ValueError: pass

    if fecha_fin:
        try:
            fecha_dt = datetime.strptime(fecha_fin, '%Y-%m-%d').date()
            query = query.filter(PedidoCompra.fecha_solicitud <= fecha_dt)
        except ValueError: pass

    # 4. Ordenamos por fecha descendente y ejecutamos
    pedidos = query.order_by(PedidoCompra.fecha_solicitud.desc()).all()
    proveedores = Proveedor.query.order_by(Proveedor.razon_social).all()
    
    return render_template('lista_pedidos.html', pedidos=pedidos, proveedores=proveedores)

@main_bp.route('/compra/nueva', methods=['GET', 'POST'])
@login_required
def nuevo_pedido():
    # CAMBIO: Creación directa de borrador (Flujo rápido)
    
    # 1. Necesitamos un proveedor por defecto ya que la BD lo exige (nullable=False)
    # Buscamos el primero disponible o creamos uno genérico
    prov = Proveedor.query.first()
    if not prov:
        try:
            prov = Proveedor(razon_social="Proveedor General", nit_rut="000")
            db.session.add(prov)
            db.session.commit()
        except Exception:
            db.session.rollback()
            flash('Error: No se pudo asignar un proveedor inicial.', 'danger')
            return redirect(url_for('main.lista_pedidos'))
            
    try:
        num_orden = f"OC-{int(datetime.now().timestamp())}"
        
        # 2. Crear pedido borrador sin formulario previo
        pedido = PedidoCompra(
            numero_orden=num_orden, 
            proveedor_id=prov.id, # Se podrá cambiar en la vista de detalle
            sede_id=None,         # Se asignará en la vista de detalle
            fecha_solicitud=datetime.now().date(), 
            estado='Borrador'
        )
        db.session.add(pedido)
        db.session.commit()
        
        # 3. Redirigir directo a la edición/agregado de productos
        return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error al iniciar pedido: {e}', 'danger')
        return redirect(url_for('main.lista_pedidos'))

@main_bp.route('/compra/<int:pedido_id>', methods=['GET'])
@login_required
def ver_pedido(pedido_id):
    pedido = PedidoCompra.query.get_or_404(pedido_id)
    insumos = Insumo.query.order_by(Insumo.nombre).all()
    proveedores = Proveedor.query.order_by(Proveedor.razon_social).all()
    sedes = Sede.query.order_by(Sede.nombre).all()
    return render_template('ver_pedido.html', pedido=pedido, insumos=insumos, proveedores=proveedores, sedes=sedes)

@main_bp.route('/compra/<int:pedido_id>/actualizar_datos', methods=['POST'])
@login_required
def actualizar_datos_pedido(pedido_id):
    pedido = PedidoCompra.query.get_or_404(pedido_id)
    if pedido.estado != 'Borrador': return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))
    try:
        prov_id = request.form.get('proveedor_id')
        sede_id = request.form.get('sede_id')
        fecha = request.form.get('fecha_solicitud')
        
        if prov_id: pedido.proveedor_id = int(prov_id)
        if sede_id: pedido.sede_id = int(sede_id)
        if fecha: pedido.fecha_solicitud = datetime.strptime(fecha, '%Y-%m-%d').date()
        
        db.session.commit()
        flash('Datos del pedido actualizados.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error: {e}', 'danger')
    return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))

@main_bp.route('/compra/<int:pedido_id>/agregar_item', methods=['POST'])
@login_required
def agregar_item_pedido(pedido_id):
    pedido = PedidoCompra.query.get_or_404(pedido_id)
    if pedido.estado != 'Borrador':
        flash('El pedido ya no es editable.', 'warning')
        return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))

    try:
        insumo_id = int(request.form.get('insumo_id'))
        cantidad = float(request.form.get('cantidad'))
        precio = float(request.form.get('precio_unitario'))

        existe = DetallePedidoCompra.query.filter_by(pedido_id=pedido.id, insumo_id=insumo_id).first()
        if existe:
            old_total = existe.cantidad_solicitada * existe.precio_unitario
            existe.cantidad_solicitada += cantidad
            existe.precio_unitario = precio 
            pedido.total_estimado -= old_total
            pedido.total_estimado += (existe.cantidad_solicitada * precio)
            flash('Producto actualizado.', 'info')
        else:
            detalle = DetallePedidoCompra(pedido_id=pedido.id, insumo_id=insumo_id, cantidad_solicitada=cantidad, cantidad_recibida=0, precio_unitario=precio)
            pedido.total_estimado += (cantidad * precio)
            db.session.add(detalle)
        
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        flash(f'Error al agregar: {e}', 'danger')
        
    return redirect(url_for('main.ver_pedido', pedido_id=pedido_id))

@main_bp.route('/compra/item/actualizar/<int:detalle_id>', methods=['POST'])
@login_required
def actualizar_item_pedido(detalle_id):
    detalle = DetallePedidoCompra.query.get_or_404(detalle_id)
    pedido = detalle.pedido
    
    if pedido.estado != 'Borrador':
        flash('No se puede editar un pedido enviado.', 'warning')
        return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))
        
    try:
        nueva_cantidad = float(request.form.get('cantidad'))
        nuevo_precio = float(request.form.get('precio_unitario'))
        
        # Validar negativos
        if nueva_cantidad < 0 or nuevo_precio < 0:
            flash('Valores no pueden ser negativos.', 'warning')
            return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))

        # Recalcular total del pedido
        total_item_anterior = detalle.cantidad_solicitada * detalle.precio_unitario
        
        detalle.cantidad_solicitada = nueva_cantidad
        detalle.precio_unitario = nuevo_precio
        
        total_item_nuevo = nueva_cantidad * nuevo_precio
        pedido.total_estimado = pedido.total_estimado - total_item_anterior + total_item_nuevo
        
        db.session.commit()
        flash('Ítem actualizado correctamente.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al actualizar: {e}', 'danger')
        
    return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))

@main_bp.route('/compra/item/eliminar/<int:detalle_id>', methods=['POST'])
@login_required
def eliminar_item_pedido(detalle_id):
    detalle = DetallePedidoCompra.query.get_or_404(detalle_id)
    pedido = detalle.pedido
    if pedido.estado != 'Borrador': return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))
    try:
        pedido.total_estimado -= (detalle.cantidad_solicitada * detalle.precio_unitario)
        db.session.delete(detalle)
        db.session.commit()
        flash('Producto eliminado.', 'info')
    except Exception: db.session.rollback()
    return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))

@main_bp.route('/compra/<int:pedido_id>/confirmar', methods=['POST'])
@login_required
def confirmar_pedido(pedido_id):
    pedido = PedidoCompra.query.get_or_404(pedido_id)
    if not pedido.detalles:
        flash('El pedido está vacío.', 'warning')
        return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))
    if not pedido.sede_id:
        flash('Selecciona la Sede de destino.', 'warning')
        return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))
    try:
        pedido.estado = 'Solicitado'
        db.session.commit()
        flash('Pedido confirmado.', 'success')
        return redirect(url_for('main.lista_pedidos'))
    except Exception as e:
        db.session.rollback()
        flash(f'Error: {e}', 'danger')
        return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))

@main_bp.route('/compra/<int:pedido_id>/cancelar', methods=['POST'])
@login_required
def cancelar_pedido(pedido_id):
    pedido = PedidoCompra.query.get_or_404(pedido_id)
    if pedido.estado in ['Recibido', 'Cancelado']: return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))
    try:
        pedido.estado = 'Cancelado'
        db.session.commit()
        flash('Cancelado.', 'secondary')
    except: db.session.rollback()
    return redirect(url_for('main.lista_pedidos'))

@main_bp.route('/api/insumo/crear_rapido', methods=['POST'])
@login_required
def crear_insumo_ajax():
    try:
        data = request.get_json()
        nuevo = Insumo(
            nombre=data.get('nombre'), tipo=data.get('tipo'), 
            unidad_medida_id=int(data.get('unidad_id')) if data.get('unidad_id') else None,
            stock_minimo=10, cantidad_actual=0
        )
        db.session.add(nuevo)
        db.session.commit()
        # Incluir unidad en la respuesta para el JS
        unidad_nombre = nuevo.unidad.abreviatura if nuevo.unidad else ''
        return jsonify({'success': True, 'id': nuevo.id, 'nombre': nuevo.nombre, 'unidad': unidad_nombre})
    except Exception as e: return jsonify({'success': False, 'message': str(e)}), 500

@main_bp.route('/compra/<int:pedido_id>/recepcion', methods=['GET'])
@login_required
def formulario_recepcion(pedido_id):
    pedido = PedidoCompra.query.get_or_404(pedido_id)
    if pedido.estado != 'Solicitado': return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))
    return render_template('recepcion_pedido.html', pedido=pedido)

@main_bp.route('/compra/<int:pedido_id>/procesar_recepcion', methods=['POST'])
@login_required
def procesar_recepcion(pedido_id):
    pedido = PedidoCompra.query.get_or_404(pedido_id)
    if pedido.estado != 'Solicitado': return redirect(url_for('main.ver_pedido', pedido_id=pedido_id))
    try:
        pedido.estado = 'Recibido'
        pedido.fecha_recepcion = datetime.utcnow().date()
        for detalle in pedido.detalles:
            cant_real = float(request.form.get(f"recibido_{detalle.id}", 0))
            detalle.cantidad_recibida = cant_real
            if cant_real > 0:
                detalle.insumo.cantidad_actual += cant_real
                lote = LoteInsumo(
                    insumo_id=detalle.insumo_id, pedido_id=pedido.id, fecha_compra=pedido.fecha_recepcion,
                    cantidad_inicial=cant_real, cantidad_actual=cant_real, costo_unitario=detalle.precio_unitario
                )
                db.session.add(lote)
                kardex = MovimientoInventario(
                    tipo_movimiento='Compra (Recepción)', cantidad=cant_real, costo_unitario=detalle.precio_unitario,
                    referencia=f"Pedido #{pedido.numero_orden}", insumo_id=detalle.insumo_id
                )
                db.session.add(kardex)
        db.session.commit()
        flash('Recepción registrada.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error: {e}', 'danger')
    return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))


# ==================================================
# 5. MÓDULO DE PRODUCCIÓN (MULTISEDE Y SECTORES)
# ==================================================

@main_bp.route('/produccion/especies')
@login_required
def lista_especies():
    query_str = request.args.get('q', '').strip()
    es_ajax = request.args.get('ajax') == '1'
    query = Especie.query
    if query_str:
        query = query.filter(or_(
            Especie.nombre_comun.ilike(f'%{query_str}%'),
            Especie.nombre_cientifico.ilike(f'%{query_str}%')
        ))
    especies = query.order_by(Especie.nombre_comun).all()
    if es_ajax: return render_template('parciales/items_especies.html', especies=especies)
    return render_template('produccion/lista_especies.html', especies=especies)

@main_bp.route('/produccion/especie/nueva', methods=['GET', 'POST'])
@login_required
def nueva_especie():
    if request.method == 'POST':
        try:
            imagen_path = None
            if 'imagen' in request.files:
                file = request.files['imagen']
                if file and file.filename != '':
                    imagen_path = guardar_imagen(file, 'especies')

            nueva = Especie(
                nombre_comun=request.form.get('nombre_comun'),
                nombre_cientifico=request.form.get('nombre_cientifico'),
                dias_ciclo_estimado=int(request.form.get('dias_ciclo') or 0),
                detalles_cuidado=request.form.get('detalles_cuidado'),
                imagen_url=imagen_path
            )
            db.session.add(nueva)
            db.session.commit()
            flash('Especie registrada con éxito.', 'success')
            return redirect(url_for('main.lista_especies'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error: {e}', 'danger')
    return render_template('produccion/nueva_especie.html')

@main_bp.route('/produccion/especie/editar_ficha/<int:especie_id>', methods=['POST'])
@login_required
def editar_ficha_especie(especie_id):
    especie = Especie.query.get_or_404(especie_id)
    lote_id_origen = request.args.get('lote_id') 
    try:
        if request.form.get('dias_ciclo'): especie.dias_ciclo_estimado = int(request.form.get('dias_ciclo'))
        especie.detalles_cuidado = request.form.get('detalles_cuidado')
        if 'imagen_editar' in request.files:
            file = request.files['imagen_editar']
            if file and file.filename != '':
                especie.imagen_url = guardar_imagen(file, 'especies')
        db.session.commit()
        flash('Ficha técnica actualizada.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al actualizar ficha: {e}', 'danger')
    
    if lote_id_origen:
        return redirect(url_for('main.ver_lote', lote_id=lote_id_origen))
    return redirect(url_for('main.lista_especies'))

@main_bp.route('/produccion/especie/eliminar/<int:especie_id>', methods=['POST'])
@login_required
def eliminar_especie(especie_id):
    especie = Especie.query.get_or_404(especie_id)
    if LoteProduccion.query.filter_by(especie_id=especie.id).count() > 0:
        flash(f'No se puede eliminar "{especie.nombre_comun}" porque tiene lotes asociados.', 'warning')
    else:
        try:
            db.session.delete(especie)
            db.session.commit()
            flash('Especie eliminada del catálogo.', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error al eliminar: {e}', 'danger')
    return redirect(url_for('main.lista_especies'))

@main_bp.route('/siembras')
@login_required
def lista_siembras():
    return redirect(url_for('main.lista_lotes'))

@main_bp.route('/siembra/nueva', methods=['GET', 'POST'])
@login_required
def nuevo_lote():
    sedes = Sede.query.order_by(Sede.nombre).all()
    especies = Especie.query.order_by(Especie.nombre_comun).all()
    today_str = datetime.utcnow().strftime('%Y-%m-%d')
    
    if request.method == 'POST':
        try:
            sede_id = request.form.get('sede_id')
            especie_id = request.form.get('especie_id')
            sector_seleccionado = request.form.get('ubicacion')
            
            if not sede_id or not especie_id or not sector_seleccionado:
                flash('Por favor selecciona Sede, Sector y Especie.', 'warning')
                return render_template('produccion/nuevo_lote.html', sedes=sedes, especies=especies, lote=None, today_str=today_str)
            
            codigo = f"SMB-{int(datetime.now().timestamp())}"
            cantidad = int(request.form.get('cantidad'))
            fecha_siembra = datetime.strptime(request.form.get('fecha_siembra'), '%Y-%m-%d').date()
            
            nuevo_lote_obj = LoteProduccion(
                codigo_lote=codigo,
                especie_id=int(especie_id),
                sede_id=int(sede_id),
                cantidad_sembrada=cantidad,
                cantidad_actual=cantidad,
                fecha_siembra=fecha_siembra,
                ubicacion=sector_seleccionado,
                estado='En Crecimiento',
                costo_total=0.0
            )
            db.session.add(nuevo_lote_obj)
            db.session.commit()
            flash('Lote registrado con éxito.', 'success')
            return redirect(url_for('main.lista_lotes'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al registrar lote: {e}', 'danger')
            
    return render_template('produccion/nuevo_lote.html', sedes=sedes, especies=especies, lote=None, today_str=today_str)


@main_bp.route('/produccion/lotes')
@login_required
def lista_lotes():
    query_str = request.args.get('q', '').strip()
    estado_filtro = request.args.get('estado')
    sede_filtro = request.args.get('sede')
    es_ajax = request.args.get('ajax') == '1'
    
    sedes = Sede.query.order_by(Sede.nombre).all()
    
    kpi_total = LoteProduccion.query.count()
    kpi_activos = LoteProduccion.query.filter_by(estado='En Crecimiento').count()
    kpi_finalizados = LoteProduccion.query.filter(LoteProduccion.estado != 'En Crecimiento').count() 
    
    query = LoteProduccion.query.join(Especie).outerjoin(Sede)
    
    if query_str:
        query = query.filter(or_(
            LoteProduccion.codigo_lote.ilike(f'%{query_str}%'),
            LoteProduccion.ubicacion.ilike(f'%{query_str}%'),
            Especie.nombre_comun.ilike(f'%{query_str}%'),
            Sede.nombre.ilike(f'%{query_str}%')
        ))
    
    if estado_filtro: query = query.filter(LoteProduccion.estado == estado_filtro)
    if sede_filtro and sede_filtro.isdigit(): query = query.filter(LoteProduccion.sede_id == int(sede_filtro))
    
    lotes = query.order_by(LoteProduccion.fecha_siembra.desc()).all()
    today = datetime.utcnow().date()
    
    if es_ajax:
        return render_template('parciales/items_lotes.html', lotes=lotes, today=today)
    
    return render_template('produccion/lista_lotes.html', 
                           lotes=lotes, 
                           sedes=sedes,
                           today=today,
                           kpi_total=kpi_total,
                           kpi_activos=kpi_activos,
                           kpi_finalizados=kpi_finalizados)

@main_bp.route('/produccion/lote/<int:lote_id>')
@login_required
def ver_lote(lote_id):
    lote = LoteProduccion.query.get_or_404(lote_id)
    insumos = Insumo.query.order_by(Insumo.nombre).all()
    return render_template('produccion/ver_lote.html', lote=lote, insumos=insumos)

@main_bp.route('/produccion/lote/eliminar/<int:lote_id>', methods=['POST'])
@login_required
def eliminar_lote(lote_id):
    lote = LoteProduccion.query.get_or_404(lote_id)
    if lote.ventas_realizadas:
        flash('No se puede eliminar este lote porque ya tiene ventas registradas.', 'warning')
        return redirect(url_for('main.ver_lote', lote_id=lote_id))

    try:
        Labores = LaborCampo.query.filter_by(lote_id=lote.id).all()
        for l in Labores:
            for c in l.consumos: db.session.delete(c)
            db.session.delete(l)
        db.session.delete(lote)
        db.session.commit()
        flash('Lote eliminado correctamente.', 'success')
        return redirect(url_for('main.lista_lotes'))
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar: {e}', 'danger')
        return redirect(url_for('main.ver_lote', lote_id=lote_id))

@main_bp.route('/produccion/lote/ajustar/<int:lote_id>', methods=['POST'])
@login_required
def ajustar_stock_lote(lote_id):
    lote = LoteProduccion.query.get_or_404(lote_id)
    try:
        nueva_cantidad = int(request.form.get('nueva_cantidad'))
        motivo = request.form.get('motivo')
        if nueva_cantidad < 0: raise ValueError("La cantidad no puede ser negativa")
        diferencia = nueva_cantidad - lote.cantidad_actual
        lote.cantidad_actual = nueva_cantidad
        labor_ajuste = LaborCampo(lote_id=lote.id, tipo_labor='Ajuste Inventario', descripcion=f"Ajuste manual: {diferencia}. Motivo: {motivo}", usuario_id=current_user.id, fecha=datetime.utcnow().date())
        db.session.add(labor_ajuste)
        if nueva_cantidad == 0: lote.estado = 'Finalizado'
        db.session.commit()
        flash(f'Stock ajustado correctamente.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al ajustar stock: {e}', 'danger')
    return redirect(url_for('main.ver_lote', lote_id=lote_id))

@main_bp.route('/produccion/labor/guardar', methods=['POST'])
@login_required
def registrar_labor():
    lote = LoteProduccion.query.get_or_404(request.form.get('lote_id'))
    try:
        labor = LaborCampo(lote_id=lote.id, tipo_labor=request.form.get('tipo_labor'), descripcion=request.form.get('descripcion'), 
                           usuario_id=current_user.id, fecha=datetime.utcnow().date())
        db.session.add(labor)
        db.session.flush() 
        costo_agregado = 0.0
        if request.form.get('insumo_id') and float(request.form.get('cantidad_insumo') or 0) > 0:
            insumo_id = request.form.get('insumo_id')
            cantidad = float(request.form.get('cantidad_insumo'))
            insumo = Insumo.query.get(insumo_id)
            if insumo.cantidad_actual < cantidad: raise Exception("Stock insuficiente.")
            insumo.cantidad_actual -= cantidad
            subtotal = cantidad * insumo.costo_promedio
            db.session.add(ConsumoInsumo(labor_id=labor.id, insumo_id=insumo.id, cantidad=cantidad, subtotal=subtotal))
            lote.costo_total += subtotal
        db.session.commit()
        flash('Labor registrada.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al registrar: {e}', 'danger')
    return redirect(url_for('main.ver_lote', lote_id=lote_id))

@main_bp.route('/produccion/labor/editar/<int:labor_id>', methods=['POST'])
@login_required
def editar_labor(labor_id):
    labor = LaborCampo.query.get_or_404(labor_id)
    try:
        labor.tipo_labor = request.form.get('tipo_labor')
        labor.descripcion = request.form.get('descripcion')
        db.session.commit()
        flash('Actualizado.', 'success')
    except: db.session.rollback()
    return redirect(url_for('main.ver_lote', lote_id=labor.lote_id))

@main_bp.route('/produccion/labor/eliminar/<int:labor_id>', methods=['POST'])
@login_required
def eliminar_labor(labor_id):
    labor = LaborCampo.query.get_or_404(labor_id)
    lote = labor.lote
    try:
        for c in labor.consumos:
            c.insumo.cantidad_actual += c.cantidad
            lote.costo_insumos -= c.subtotal
            lote.costo_total -= c.subtotal
            db.session.delete(c)
        db.session.delete(labor)
        db.session.commit()
        flash('Labor eliminada.', 'success')
    except: db.session.rollback()
    return redirect(url_for('main.ver_lote', lote_id=lote.id))


# ==================================================
# 6. MÓDULO DE VENTAS Y CLIENTES
# ==================================================

# --- GESTIÓN DE CLIENTES ---
@main_bp.route('/clientes')
@login_required
def lista_clientes():
    q = request.args.get('q', '').strip()
    query = Cliente.query
    if q: query = query.filter(or_(Cliente.nombre.ilike(f'%{q}%'), Cliente.documento.ilike(f'%{q}%')))
    return render_template('ventas/lista_clientes.html', clientes=query.all(), search_query=q)

@main_bp.route('/cliente/nuevo', methods=['GET', 'POST'])
@login_required
def nuevo_cliente():
    if request.method == 'POST':
        try:
            c = Cliente(
                nombre=request.form.get('nombre'),
                documento=request.form.get('documento'),
                telefono=request.form.get('telefono'),
                email=request.form.get('email'),
                direccion=request.form.get('direccion')
            )
            db.session.add(c)
            db.session.commit()
            flash('Cliente registrado.', 'success')
            return redirect(url_for('main.lista_clientes'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error: {e}', 'danger')
    return render_template('ventas/nuevo_cliente.html')

# --- GESTIÓN DE VENTAS ---
@main_bp.route('/ventas')
@login_required
def lista_ventas():
    # 1. Capturar filtros (para soportar el clic desde el Dashboard)
    fecha_ini_str = request.args.get('fecha_inicio')
    fecha_fin_str = request.args.get('fecha_fin')
    
    query = Venta.query

    # 2. Aplicar lógica de filtrado
    if fecha_ini_str:
        try:
            fecha_ini = datetime.strptime(fecha_ini_str, '%Y-%m-%d')
            query = query.filter(Venta.fecha >= fecha_ini)
        except ValueError: pass
        
    if fecha_fin_str:
        try:
            # Ajustamos al final del día
            fecha_fin = datetime.strptime(fecha_fin_str, '%Y-%m-%d').replace(hour=23, minute=59, second=59)
            query = query.filter(Venta.fecha <= fecha_fin)
        except ValueError: pass

    ventas = query.order_by(Venta.fecha.desc()).all()
    return render_template('ventas/lista_ventas.html', ventas=ventas)

@main_bp.route('/venta/nueva', methods=['GET', 'POST'])
@login_required
def nueva_venta():
    # 1. Buscar o Crear "Cliente Mostrador" por defecto
    cliente_defecto = Cliente.query.filter_by(nombre='Cliente Mostrador').first()
    if not cliente_defecto:
        try:
            cliente_defecto = Cliente(nombre='Cliente Mostrador', documento='222222222', direccion='Local', email='ventas@local.com')
            db.session.add(cliente_defecto)
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            flash(f'Error al crear cliente por defecto: {e}', 'danger')
            return redirect(url_for('main.lista_ventas'))

    # 2. Crear Venta Borrador inmediatamente
    try:
        v = Venta(
            numero_factura=f"FAC-{int(datetime.now().timestamp())}",
            cliente_id=cliente_defecto.id,
            usuario_id=current_user.id,
            estado='Borrador'
        )
        db.session.add(v)
        db.session.commit()
        # Redirigir directo a agregar items
        return redirect(url_for('main.ver_venta', venta_id=v.id))
    except Exception as e:
        db.session.rollback()
        flash(f'Error al iniciar venta: {e}', 'danger')
        return redirect(url_for('main.lista_ventas'))

@main_bp.route('/venta/<int:venta_id>')
@login_required
def ver_venta(venta_id):
    venta = Venta.query.get_or_404(venta_id)
    # Solo lotes que tengan plantas disponibles
    lotes_disponibles = LoteProduccion.query.filter(LoteProduccion.cantidad_actual > 0, LoteProduccion.estado != 'Cancelado').all()
    # Clientes para el modal de cambio
    clientes = Cliente.query.order_by(Cliente.nombre).all()
    return render_template('ventas/ver_venta.html', venta=venta, lotes=lotes_disponibles, clientes=clientes)

@main_bp.route('/venta/<int:venta_id>/cambiar_cliente', methods=['POST'])
@login_required
def cambiar_cliente_venta(venta_id):
    venta = Venta.query.get_or_404(venta_id)
    if venta.estado != 'Borrador':
        return redirect(url_for('main.ver_venta', venta_id=venta_id))
    
    try:
        nuevo_cliente_id = request.form.get('cliente_id')
        if nuevo_cliente_id:
            venta.cliente_id = int(nuevo_cliente_id)
            db.session.commit()
            flash('Cliente actualizado correctamente.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al cambiar cliente: {e}', 'danger')
        
    return redirect(url_for('main.ver_venta', venta_id=venta_id))

@main_bp.route('/venta/<int:venta_id>/agregar', methods=['POST'])
@login_required
def agregar_item_venta(venta_id):
    venta = Venta.query.get_or_404(venta_id)
    if venta.estado != 'Borrador': return redirect(url_for('main.ver_venta', venta_id=venta_id))
        
    try:
        lote_id = request.form.get('lote_id')
        cantidad = int(request.form.get('cantidad'))
        precio_venta = float(request.form.get('precio_unitario'))
        
        lote = LoteProduccion.query.get(lote_id)
        if lote.cantidad_actual < cantidad:
            flash(f'Stock insuficiente en lote {lote.codigo_lote}.', 'warning')
            return redirect(url_for('main.ver_venta', venta_id=venta_id))
            
        costo_prod_unitario = 0
        if lote.cantidad_actual > 0:
            costo_prod_unitario = lote.costo_total / lote.cantidad_actual
            
        subtotal = cantidad * precio_venta
        ganancia = subtotal - (cantidad * costo_prod_unitario)
        
        detalle = DetalleVenta(
            venta_id=venta.id, lote_id=lote.id, cantidad=cantidad,
            precio_venta_unitario=precio_venta, costo_produccion_unitario=costo_prod_unitario,
            subtotal=subtotal, ganancia=ganancia
        )
        venta.total += subtotal
        db.session.add(detalle)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        flash(f'Error: {e}', 'danger')
        
    return redirect(url_for('main.ver_venta', venta_id=venta_id))

@main_bp.route('/venta/<int:venta_id>/finalizar', methods=['POST'])
@login_required
def finalizar_venta(venta_id):
    venta = Venta.query.get_or_404(venta_id)
    if venta.estado != 'Borrador': return redirect(url_for('main.ver_venta', venta_id=venta_id))
    
    try:
        for d in venta.detalles:
            lote = d.lote_origen
            if lote.cantidad_actual < d.cantidad:
                raise Exception(f"El lote {lote.codigo_lote} ya no tiene stock.")
            
            lote.cantidad_actual -= d.cantidad
            costo_salida = d.cantidad * d.costo_produccion_unitario
            lote.costo_total -= costo_salida
            
            if lote.cantidad_actual == 0: lote.estado = 'Finalizado'
                
        venta.estado = 'Finalizada'
        db.session.commit()
        flash('Venta registrada con éxito.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al finalizar venta: {e}', 'danger')
        
    return redirect(url_for('main.ver_venta', venta_id=venta_id))


# ==================================================
# 7. CONFIGURACIÓN (SEDES)
# ==================================================

@main_bp.route('/configuracion/sedes')
@login_required
def lista_sedes():
    sedes = Sede.query.order_by(Sede.nombre).all()
    # Calculamos algunos datos rápidos para mostrar en las tarjetas
    for sede in sedes:
        sede.total_lotes = LoteProduccion.query.filter_by(sede_id=sede.id).count()
        sede.lotes_activos = LoteProduccion.query.filter_by(sede_id=sede.id, estado='En Crecimiento').count()
    return render_template('lista_sedes.html', sedes=sedes)

@main_bp.route('/configuracion/sede/nueva', methods=['GET', 'POST'])
@main_bp.route('/configuracion/sede/editar/<int:sede_id>', methods=['GET', 'POST'])
@login_required
def nueva_sede(sede_id=None):
    sede = Sede.query.get_or_404(sede_id) if sede_id else None
    
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        tipo = request.form.get('tipo') # Finca o Vivero
        ubicacion = request.form.get('ubicacion_geo')
        
        if not nombre:
            flash('El nombre de la sede es obligatorio.', 'warning')
            return render_template('nueva_sede.html', sede=sede)

        try:
            if sede:
                sede.nombre = nombre
                sede.tipo = tipo
                sede.ubicacion_geo = ubicacion
                flash('Información de la sede actualizada.', 'success')
            else:
                nueva = Sede(nombre=nombre, tipo=request.form.get('tipo'), ubicacion_geo=request.form.get('ubicacion_geo'))
                db.session.add(nueva)
                flash('Nueva sede registrada exitosamente.', 'success')
            db.session.commit()
            return redirect(url_for('main.lista_sedes'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al guardar sede: {e}', 'danger')

    return render_template('nueva_sede.html', sede=sede)

@main_bp.route('/configuracion/sede/eliminar/<int:sede_id>', methods=['POST'])
@login_required
def eliminar_sede(sede_id):
    sede = Sede.query.get_or_404(sede_id)
    # Protección: No borrar si tiene lotes
    lotes_asociados = LoteProduccion.query.filter_by(sede_id=sede.id).count()
    if lotes_asociados > 0:
        flash(f'No se puede eliminar "{sede.nombre}" porque tiene {lotes_asociados} lotes de producción asociados. Elimina o mueve los lotes primero.', 'warning')
        return redirect(url_for('main.lista_sedes'))
    
    try:
        db.session.delete(sede)
        db.session.commit()
        flash('Sede eliminada del sistema.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar: {e}', 'danger')
    return redirect(url_for('main.lista_sedes'))