from .extensions import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

# ... (Usuario, Rol, Proveedor, UnidadMedida se mantienen igual) ...

class Usuario(UserMixin, db.Model):
    __tablename__ = 'usuarios'
    id = db.Column(db.Integer, primary_key=True)
    nombre_completo = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    telefono = db.Column(db.String(20))
    rol_id = db.Column(db.Integer, db.ForeignKey('roles.id'))
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    ventas = db.relationship('Venta', backref='vendedor', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Rol(db.Model):
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50), unique=True, nullable=False)
    usuarios = db.relationship('Usuario', backref='rol', lazy=True)

class Proveedor(db.Model):
    __tablename__ = 'proveedores'
    id = db.Column(db.Integer, primary_key=True)
    razon_social = db.Column(db.String(100), nullable=False)
    nit_rut = db.Column(db.String(20))
    contacto_nombre = db.Column(db.String(100))
    telefono = db.Column(db.String(20))
    email = db.Column(db.String(100))
    direccion = db.Column(db.String(200))
    pedidos = db.relationship('PedidoCompra', backref='proveedor', lazy=True)

class UnidadMedida(db.Model):
    __tablename__ = 'unidades_medida'
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50), nullable=False)
    abreviatura = db.Column(db.String(10), nullable=False)
    insumos = db.relationship('Insumo', backref='unidad', lazy=True)

class Sede(db.Model):
    __tablename__ = 'sedes'
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    tipo = db.Column(db.String(50))
    ubicacion_geo = db.Column(db.String(200))
    lotes = db.relationship('LoteProduccion', backref='sede', lazy=True)
    # Relación con Pedidos (Destino de la compra)
    pedidos = db.relationship('PedidoCompra', backref='sede_destino', lazy=True)

class Insumo(db.Model):
    __tablename__ = 'insumos'
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    tipo = db.Column(db.String(50)) 
    unidad_medida_id = db.Column(db.Integer, db.ForeignKey('unidades_medida.id'))
    # ELIMINADO: sede_id (El insumo es global en el catálogo)
    stock_minimo = db.Column(db.Float, default=0)
    cantidad_actual = db.Column(db.Float, default=0) # Stock Global Total
    costo_promedio = db.Column(db.Float, default=0)
    imagen_url = db.Column(db.String(255))
    
    detalles_pedido = db.relationship('DetallePedidoCompra', backref='insumo', lazy=True)
    lotes = db.relationship('LoteInsumo', backref='insumo', lazy=True)
    movimientos = db.relationship('MovimientoInventario', backref='insumo', lazy=True)
    consumos = db.relationship('ConsumoInsumo', backref='insumo', lazy=True)

class PedidoCompra(db.Model):
    __tablename__ = 'pedidos_compra'
    id = db.Column(db.Integer, primary_key=True)
    numero_orden = db.Column(db.String(50), unique=True)
    proveedor_id = db.Column(db.Integer, db.ForeignKey('proveedores.id'), nullable=False)
    sede_id = db.Column(db.Integer, db.ForeignKey('sedes.id')) # <-- NUEVO: Para dónde va la compra
    fecha_solicitud = db.Column(db.Date, nullable=False)
    fecha_recepcion = db.Column(db.Date)
    estado = db.Column(db.String(20), default='Solicitado')
    total_estimado = db.Column(db.Float, default=0)
    detalles = db.relationship('DetallePedidoCompra', backref='pedido', lazy=True)
    lotes_recibidos = db.relationship('LoteInsumo', backref='pedido_origen', lazy=True)

# ... (El resto de modelos DetallePedidoCompra, LoteInsumo, etc. siguen igual) ...
class DetallePedidoCompra(db.Model):
    __tablename__ = 'detalles_pedido_compra'
    id = db.Column(db.Integer, primary_key=True)
    pedido_id = db.Column(db.Integer, db.ForeignKey('pedidos_compra.id'), nullable=False)
    insumo_id = db.Column(db.Integer, db.ForeignKey('insumos.id'), nullable=False)
    cantidad_solicitada = db.Column(db.Float, nullable=False)
    cantidad_recibida = db.Column(db.Float, default=0)
    precio_unitario = db.Column(db.Float, nullable=False)

class LoteInsumo(db.Model):
    __tablename__ = 'lotes_insumo'
    id = db.Column(db.Integer, primary_key=True)
    insumo_id = db.Column(db.Integer, db.ForeignKey('insumos.id'), nullable=False)
    pedido_id = db.Column(db.Integer, db.ForeignKey('pedidos_compra.id'))
    fecha_compra = db.Column(db.Date)
    cantidad_inicial = db.Column(db.Float, nullable=False)
    cantidad_actual = db.Column(db.Float, nullable=False)
    costo_unitario = db.Column(db.Float, nullable=False)

class MovimientoInventario(db.Model):
    __tablename__ = 'movimientos_inventario'
    id = db.Column(db.Integer, primary_key=True)
    fecha = db.Column(db.DateTime, default=datetime.utcnow)
    tipo_movimiento = db.Column(db.String(50))
    insumo_id = db.Column(db.Integer, db.ForeignKey('insumos.id'), nullable=False)
    cantidad = db.Column(db.Float)
    costo_unitario = db.Column(db.Float)
    referencia = db.Column(db.String(100))

class Especie(db.Model):
    __tablename__ = 'especies'
    id = db.Column(db.Integer, primary_key=True)
    nombre_comun = db.Column(db.String(100), nullable=False)
    nombre_cientifico = db.Column(db.String(100))
    dias_ciclo_estimado = db.Column(db.Integer)
    detalles_cuidado = db.Column(db.Text)
    imagen_url = db.Column(db.String(255))
    lotes = db.relationship('LoteProduccion', backref='especie', lazy=True)

class LoteProduccion(db.Model):
    __tablename__ = 'lotes_produccion'
    id = db.Column(db.Integer, primary_key=True)
    codigo_lote = db.Column(db.String(50), unique=True, nullable=False)
    especie_id = db.Column(db.Integer, db.ForeignKey('especies.id'), nullable=False)
    sede_id = db.Column(db.Integer, db.ForeignKey('sedes.id'))
    cantidad_sembrada = db.Column(db.Integer, nullable=False)
    cantidad_actual = db.Column(db.Integer, nullable=False)
    fecha_siembra = db.Column(db.Date, nullable=False)
    fecha_cosecha_estimada = db.Column(db.Date)
    ubicacion = db.Column(db.String(100))
    estado = db.Column(db.String(50), default='En Crecimiento')
    costo_total = db.Column(db.Float, default=0)
    labores = db.relationship('LaborCampo', backref='lote', lazy=True)
    ventas_realizadas = db.relationship('DetalleVenta', backref='lote_origen', lazy=True)

class LaborCampo(db.Model):
    __tablename__ = 'labores_campo'
    id = db.Column(db.Integer, primary_key=True)
    lote_id = db.Column(db.Integer, db.ForeignKey('lotes_produccion.id'), nullable=False)
    tipo_labor = db.Column(db.String(100), nullable=False)
    descripcion = db.Column(db.Text)
    fecha = db.Column(db.Date, nullable=False)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'))
    consumos = db.relationship('ConsumoInsumo', backref='labor', lazy=True, cascade="all, delete-orphan")

class ConsumoInsumo(db.Model):
    __tablename__ = 'consumos_insumo'
    id = db.Column(db.Integer, primary_key=True)
    labor_id = db.Column(db.Integer, db.ForeignKey('labores_campo.id'), nullable=False)
    insumo_id = db.Column(db.Integer, db.ForeignKey('insumos.id'), nullable=False)
    cantidad = db.Column(db.Float, nullable=False)
    costo_unitario_calculado = db.Column(db.Float)
    subtotal = db.Column(db.Float)

class Cliente(db.Model):
    __tablename__ = 'clientes'
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    documento = db.Column(db.String(20))
    telefono = db.Column(db.String(20))
    email = db.Column(db.String(100))
    direccion = db.Column(db.String(200))
    ventas = db.relationship('Venta', backref='cliente', lazy=True)

class Venta(db.Model):
    __tablename__ = 'ventas'
    id = db.Column(db.Integer, primary_key=True)
    numero_factura = db.Column(db.String(50), unique=True)
    cliente_id = db.Column(db.Integer, db.ForeignKey('clientes.id'), nullable=False)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'))
    fecha = db.Column(db.DateTime, default=datetime.utcnow)
    total = db.Column(db.Float, default=0)
    estado = db.Column(db.String(20), default='Borrador')
    detalles = db.relationship('DetalleVenta', backref='venta', lazy=True)

class DetalleVenta(db.Model):
    __tablename__ = 'detalles_venta'
    id = db.Column(db.Integer, primary_key=True)
    venta_id = db.Column(db.Integer, db.ForeignKey('ventas.id'), nullable=False)
    lote_id = db.Column(db.Integer, db.ForeignKey('lotes_produccion.id'), nullable=False)
    cantidad = db.Column(db.Integer, nullable=False)
    precio_venta_unitario = db.Column(db.Float, nullable=False)
    costo_produccion_unitario = db.Column(db.Float)
    subtotal = db.Column(db.Float, nullable=False)
    ganancia = db.Column(db.Float)