import os
from sqlalchemy import text
from app import create_app, db  # Asumiendo que usas create_app en tu __init__.py

app = create_app()

with app.app_context():
    print("--- 🛠️ Iniciando reparación de Base de Datos ---")
    
    # Paso 1: Agregar la nueva columna a la tabla Especies
    try:
        print("1. Intentando agregar campo 'detalles_cuidado' a tabla 'especies'...")
        with db.engine.connect() as conn:
            conn.execute(text("ALTER TABLE especies ADD COLUMN detalles_cuidado TEXT;"))
            conn.commit()
        print("   ✅ ¡Éxito! Columna creada.")
    except Exception as e:
        if "Duplicate column" in str(e):
            print("   ℹ️ La columna ya existía, continuamos.")
        else:
            print(f"   ⚠️ Nota: {e}")

    # Paso 2: Limpiar la columna vieja de la tabla Lotes (Opcional, para limpieza)
    try:
        print("2. Intentando eliminar campo obsoleto 'detalles_cuidado' de 'lotes_produccion'...")
        with db.engine.connect() as conn:
            conn.execute(text("ALTER TABLE lotes_produccion DROP COLUMN detalles_cuidado;"))
            conn.commit()
        print("   ✅ ¡Éxito! Columna obsoleta eliminada.")
    except Exception as e:
        print(f"   ℹ️ Nota: {e} (Probablemente ya no existía).")

    print("\n--- ✅ Proceso finalizado. Ahora puedes correr tu app normalmente. ---")