from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from sqlalchemy import or_
from .models import (
    Usuario, Rol, Proveedor, Insumo, UnidadMedida, 
    PedidoCompra, DetallePedidoCompra, LoteInsumo, MovimientoInventario,
    Especie, LoteProduccion, LaborCampo, ConsumoInsumo,
    Cliente, Venta, DetalleVenta
)
from .extensions import db
from datetime import datetime

main_bp = Blueprint('main', __name__)

# ==================================================
# 1. RUTAS PÚBLICAS Y AUTENTICACIÓN
# ==================================================

@main_bp.route('/')
def home():
    return render_template('index.html')

@main_bp.route('/registro', methods=['GET', 'POST'])
def registro():
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))

    if not Rol.query.first():
        try:
            roles_iniciales = [Rol(nombre='Administrador'), Rol(nombre='Trabajador'), Rol(nombre='Agrónomo'), Rol(nombre='Vendedor')]
            db.session.add_all(roles_iniciales)
            db.session.commit()
        except: db.session.rollback()

    if request.method == 'POST':
        nombre = request.form.get('nombre')
        email = request.form.get('email')
        password = request.form.get('password')
        telefono = request.form.get('telefono')
        rol_nombre = request.form.get('rol') 

        if not nombre or not email or not password:
            flash('Por favor llena los campos obligatorios.', 'warning')
            return render_template('registro.html')

        if Usuario.query.filter_by(email=email).first():
            flash('El correo ya está registrado.', 'warning')
            return render_template('registro.html')

        rol_obj = Rol.query.filter_by(nombre=rol_nombre).first()
        if not rol_obj: rol_obj = Rol.query.filter_by(nombre='Trabajador').first()

        try:
            nuevo_usuario = Usuario(
                nombre_completo=nombre, email=email, telefono=telefono,
                rol_id=rol_obj.id if rol_obj else None, fecha_registro=datetime.utcnow()
            )
            nuevo_usuario.set_password(password)
            db.session.add(nuevo_usuario)
            db.session.commit()
            flash('¡Cuenta creada! Por favor inicia sesión.', 'success')
            return redirect(url_for('main.login'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al registrar: {e}', 'danger')

    try: roles = Rol.query.all()
    except: roles = []
    return render_template('registro.html', roles=roles)

@main_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated: return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = Usuario.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user)
            flash(f'Bienvenido, {user.nombre_completo}', 'success')
            return redirect(url_for('main.dashboard'))
        else:
            flash('Email o contraseña incorrectos.', 'danger')
    return render_template('login.html')

@main_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.home'))

@main_bp.route('/dashboard')
@login_required
def dashboard():
    # 1. Conteos Generales
    total_insumos = Insumo.query.count()
    total_proveedores = Proveedor.query.count()
    insumos_alerta = Insumo.query.filter(Insumo.cantidad_actual <= Insumo.stock_minimo).all()
    pedidos_pendientes = PedidoCompra.query.filter_by(estado='Solicitado').count()
    
    # 2. KPIs de Producción y Ventas
    lotes_activos = LoteProduccion.query.filter_by(estado='En Crecimiento').count()
    fecha_inicio_mes = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    ventas_mes = Venta.query.filter(Venta.fecha >= fecha_inicio_mes).count()
    
    # 3. DATOS PARA MODALES DE ACCIÓN RÁPIDA
    especies = Especie.query.all()
    proveedores = Proveedor.query.order_by(Proveedor.razon_social).all()
    unidades = UnidadMedida.query.all()
    
    # Aseguramos unidades básicas si no existen
    if not unidades:
        try:
            db.session.add_all([UnidadMedida(nombre='Unidad', abreviatura='ud'), UnidadMedida(nombre='Kilogramo', abreviatura='kg')])
            db.session.commit()
            unidades = UnidadMedida.query.all()
        except: pass

    return render_template('dashboard.html',
                           total_insumos=total_insumos,
                           total_proveedores=total_proveedores,
                           insumos_alerta=insumos_alerta,
                           pedidos_pendientes=pedidos_pendientes,
                           lotes_activos=lotes_activos,
                           ventas_mes=ventas_mes,
                           especies=especies,
                           proveedores=proveedores,
                           unidades=unidades)


# ==================================================
# 2. GESTIÓN DE TERCEROS (PROVEEDORES) - ACTUALIZADO AJAX
# ==================================================

@main_bp.route('/proveedores')
@login_required
def lista_proveedores():
    query_str = request.args.get('q', '').strip()
    es_ajax = request.args.get('ajax') == '1' # Detectar petición dinámica
    
    query = Proveedor.query
    
    if query_str:
        query = query.filter(or_(
            Proveedor.razon_social.ilike(f'%{query_str}%'),
            Proveedor.nit_rut.ilike(f'%{query_str}%'),
            Proveedor.contacto_nombre.ilike(f'%{query_str}%')
        ))
    
    proveedores = query.order_by(Proveedor.razon_social).all()
    
    # --- RESPUESTA DINÁMICA ---
    # Si es AJAX, devolvemos solo las filas de la tabla
    if es_ajax:
        return render_template('parciales/items_proveedores.html', proveedores=proveedores)
        
    # Si es normal, devolvemos la página completa
    return render_template('lista_proveedores.html', proveedores=proveedores, search_query=query_str)

@main_bp.route('/proveedor/nuevo', methods=['GET', 'POST'])
@main_bp.route('/proveedor/editar/<int:proveedor_id>', methods=['GET', 'POST'])
@login_required
def nuevo_proveedor(proveedor_id=None):
    proveedor = None
    if proveedor_id:
        proveedor = Proveedor.query.get_or_404(proveedor_id)

    if request.method == 'POST':
        razon_social = request.form.get('razon_social')
        nit_rut = request.form.get('nit_rut') or None 
        contacto = request.form.get('contacto_nombre')
        telefono = request.form.get('telefono')
        email = request.form.get('email')
        direccion = request.form.get('direccion')

        if not razon_social:
            flash('La Razón Social es obligatoria.', 'warning')
            return render_template('nuevo_proveedor.html', proveedor=proveedor)
        
        try:
            if proveedor:
                proveedor.razon_social = razon_social
                proveedor.nit_rut = nit_rut
                proveedor.contacto_nombre = contacto
                proveedor.telefono = telefono
                proveedor.email = email
                proveedor.direccion = direccion
                flash('Proveedor actualizado exitosamente.', 'success')
            else:
                nuevo = Proveedor(
                    razon_social=razon_social, nit_rut=nit_rut, contacto_nombre=contacto,
                    telefono=telefono, email=email, direccion=direccion
                )
                db.session.add(nuevo)
                flash('Proveedor registrado exitosamente.', 'success')
            
            db.session.commit()
            return redirect(url_for('main.lista_proveedores'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al guardar: {e}', 'danger')
            return render_template('nuevo_proveedor.html', proveedor=proveedor)

    return render_template('nuevo_proveedor.html', proveedor=proveedor)

@main_bp.route('/proveedor/eliminar/<int:proveedor_id>', methods=['POST'])
@login_required
def eliminar_proveedor(proveedor_id):
    proveedor = Proveedor.query.get_or_404(proveedor_id)
    try:
        db.session.delete(proveedor)
        db.session.commit()
        flash('Proveedor eliminado.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar: {e}', 'danger')
    return redirect(url_for('main.lista_proveedores'))


# ==================================================
# 3. GESTIÓN DE INVENTARIOS (INSUMOS)
# ==================================================

@main_bp.route('/insumos')
@login_required
def lista_insumos():
    query = request.args.get('q', '').strip()
    if query:
        insumos = Insumo.query.filter(or_(
            Insumo.nombre.ilike(f'%{query}%'),
            Insumo.tipo.ilike(f'%{query}%')
        )).all()
        if not insumos: flash(f'No se encontraron insumos con "{query}".', 'info')
    else:
        insumos = Insumo.query.all()
    return render_template('lista_insumos.html', insumos=insumos, search_query=query)

@main_bp.route('/insumo/nuevo', methods=['GET', 'POST'])
@main_bp.route('/insumo/editar/<int:insumo_id>', methods=['GET', 'POST'])
@login_required
def nuevo_insumo(insumo_id=None):
    if not UnidadMedida.query.first():
        try:
            unidades = [
                UnidadMedida(nombre='Kilogramo', abreviatura='kg'),
                UnidadMedida(nombre='Litro', abreviatura='L'),
                UnidadMedida(nombre='Unidad', abreviatura='ud'),
                UnidadMedida(nombre='Saco 50kg', abreviatura='saco')
            ]
            db.session.add_all(unidades)
            db.session.commit()
        except: db.session.rollback()

    unidades = UnidadMedida.query.all()
    insumo = None
    if insumo_id:
        insumo = Insumo.query.get_or_404(insumo_id)

    if request.method == 'POST':
        nombre = request.form.get('nombre')
        tipo = request.form.get('tipo')
        unidad_id = request.form.get('unidad_id')
        stock_min = float(request.form.get('stock_minimo', 0))

        if not nombre:
            flash('El nombre es obligatorio.', 'warning')
            return render_template('nuevo_insumo.html', unidades=unidades, insumo=insumo)

        try:
            if insumo:
                insumo.nombre = nombre
                insumo.tipo = tipo
                insumo.unidad_medida_id = int(unidad_id) if unidad_id else None
                insumo.stock_minimo = stock_min
                flash('Insumo actualizado correctamente.', 'success')
            else:
                nuevo = Insumo(
                    nombre=nombre, tipo=tipo,
                    unidad_medida_id=int(unidad_id) if unidad_id else None,
                    stock_minimo=stock_min, cantidad_actual=0.0, costo_promedio=0.0
                )
                db.session.add(nuevo)
                flash('Insumo creado correctamente.', 'success')
            
            db.session.commit()
            return redirect(url_for('main.lista_insumos'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al guardar insumo: {e}', 'danger')
            return render_template('nuevo_insumo.html', unidades=unidades, insumo=insumo)

    return render_template('nuevo_insumo.html', unidades=unidades, insumo=insumo)

@main_bp.route('/insumo/eliminar/<int:insumo_id>', methods=['POST'])
@login_required
def eliminar_insumo(insumo_id):
    insumo = Insumo.query.get_or_404(insumo_id)
    try:
        db.session.delete(insumo)
        db.session.commit()
        flash('Insumo eliminado del sistema.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'No se pudo eliminar: {e}', 'danger')
    return redirect(url_for('main.lista_insumos'))


# ==================================================
# 4. GESTIÓN DE COMPRAS (PEDIDOS, FIFO Y AJAX)
# ==================================================

@main_bp.route('/compras')
@login_required
def lista_pedidos():
    estado_filtro = request.args.get('estado')
    proveedor_id = request.args.get('proveedor_id')
    fecha_inicio = request.args.get('fecha_inicio')
    fecha_fin = request.args.get('fecha_fin')

    query = PedidoCompra.query

    if estado_filtro: query = query.filter_by(estado=estado_filtro)
    if proveedor_id: query = query.filter_by(proveedor_id=int(proveedor_id))
    if fecha_inicio:
        try: query = query.filter(PedidoCompra.fecha_solicitud >= datetime.strptime(fecha_inicio, '%Y-%m-%d').date())
        except: pass
    if fecha_fin:
        try: query = query.filter(PedidoCompra.fecha_solicitud <= datetime.strptime(fecha_fin, '%Y-%m-%d').date())
        except: pass

    pedidos = query.order_by(PedidoCompra.fecha_solicitud.desc()).all()
    proveedores = Proveedor.query.order_by(Proveedor.razon_social).all()
    return render_template('lista_pedidos.html', pedidos=pedidos, proveedores=proveedores)

@main_bp.route('/compra/nueva', methods=['GET', 'POST'])
@login_required
def nuevo_pedido():
    proveedores = Proveedor.query.all()
    if request.method == 'POST':
        proveedor_id = request.form.get('proveedor_id')
        fecha_str = request.form.get('fecha_solicitud')
        
        try:
            fecha = datetime.strptime(fecha_str, '%Y-%m-%d').date()
            num_orden = f"OC-{int(datetime.now().timestamp())}"
            pedido = PedidoCompra(numero_orden=num_orden, proveedor_id=int(proveedor_id), fecha_solicitud=fecha, estado='Solicitado')
            db.session.add(pedido)
            db.session.commit()
            flash('Pedido creado. Ahora agrega los productos.', 'success')
            return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al crear pedido: {e}', 'danger')

    return render_template('nuevo_pedido.html', proveedores=proveedores)

@main_bp.route('/compra/<int:pedido_id>', methods=['GET'])
@login_required
def ver_pedido(pedido_id):
    pedido = PedidoCompra.query.get_or_404(pedido_id)
    insumos = Insumo.query.order_by(Insumo.nombre).all()
    unidades = UnidadMedida.query.all()
    return render_template('ver_pedido.html', pedido=pedido, insumos=insumos, unidades=unidades)

@main_bp.route('/compra/<int:pedido_id>/agregar_item', methods=['POST'])
@login_required
def agregar_item_pedido(pedido_id):
    pedido = PedidoCompra.query.get_or_404(pedido_id)
    if pedido.estado != 'Solicitado':
        flash('No se pueden modificar pedidos ya recibidos.', 'warning')
        return redirect(url_for('main.ver_pedido', pedido_id=pedido_id))

    try:
        insumo_id = int(request.form.get('insumo_id'))
        cantidad = float(request.form.get('cantidad'))
        precio = float(request.form.get('precio_unitario'))

        existe = DetallePedidoCompra.query.filter_by(pedido_id=pedido.id, insumo_id=insumo_id).first()
        if existe:
            old_total = existe.cantidad_solicitada * existe.precio_unitario
            existe.cantidad_solicitada += cantidad
            existe.precio_unitario = precio 
            pedido.total_estimado -= old_total
            pedido.total_estimado += (existe.cantidad_solicitada * precio)
            flash('Producto actualizado en la lista.', 'info')
        else:
            detalle = DetallePedidoCompra(pedido_id=pedido.id, insumo_id=insumo_id, cantidad_solicitada=cantidad, cantidad_recibida=0, precio_unitario=precio)
            pedido.total_estimado += (cantidad * precio)
            db.session.add(detalle)
        
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        flash(f'Error al agregar item: {e}', 'danger')
        
    return redirect(url_for('main.ver_pedido', pedido_id=pedido_id))

@main_bp.route('/compra/item/actualizar/<int:detalle_id>', methods=['POST'])
@login_required
def actualizar_item_pedido(detalle_id):
    detalle = DetallePedidoCompra.query.get_or_404(detalle_id)
    pedido = detalle.pedido
    if pedido.estado != 'Solicitado': return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))
    try:
        nueva_cantidad = float(request.form.get('cantidad'))
        nuevo_precio = float(request.form.get('precio_unitario'))
        total_viejo = detalle.cantidad_solicitada * detalle.precio_unitario
        detalle.cantidad_solicitada = nueva_cantidad
        detalle.precio_unitario = nuevo_precio
        pedido.total_estimado = pedido.total_estimado - total_viejo + (nueva_cantidad * nuevo_precio)
        db.session.commit()
        flash('Item actualizado.', 'success')
    except Exception: db.session.rollback()
    return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))

@main_bp.route('/compra/item/eliminar/<int:detalle_id>', methods=['POST'])
@login_required
def eliminar_item_pedido(detalle_id):
    detalle = DetallePedidoCompra.query.get_or_404(detalle_id)
    pedido = detalle.pedido
    if pedido.estado != 'Solicitado': return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))
    try:
        pedido.total_estimado -= (detalle.cantidad_solicitada * detalle.precio_unitario)
        db.session.delete(detalle)
        db.session.commit()
        flash('Producto eliminado.', 'info')
    except Exception: db.session.rollback()
    return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))

@main_bp.route('/compra/<int:pedido_id>/cancelar', methods=['POST'])
@login_required
def cancelar_pedido(pedido_id):
    pedido = PedidoCompra.query.get_or_404(pedido_id)
    if pedido.estado != 'Solicitado': return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))
    try:
        pedido.estado = 'Cancelado'
        db.session.commit()
        flash('Pedido CANCELADO.', 'secondary')
    except: db.session.rollback()
    return redirect(url_for('main.ver_pedido', pedido_id=pedido.id))

@main_bp.route('/api/insumo/crear_rapido', methods=['POST'])
@login_required
def crear_insumo_ajax():
    try:
        data = request.get_json()
        nuevo = Insumo(
            nombre=data.get('nombre'), tipo=data.get('tipo'), 
            unidad_medida_id=int(data.get('unidad_id')) if data.get('unidad_id') else None,
            stock_minimo=10, cantidad_actual=0
        )
        db.session.add(nuevo)
        db.session.commit()
        return jsonify({'success': True, 'id': nuevo.id, 'nombre': nuevo.nombre, 'unidad': nuevo.unidad.abreviatura if nuevo.unidad else ''})
    except Exception as e: return jsonify({'success': False, 'message': str(e)}), 500

@main_bp.route('/compra/<int:pedido_id>/recepcion', methods=['GET'])
@login_required
def formulario_recepcion(pedido_id):
    pedido = PedidoCompra.query.get_or_404(pedido_id)
    if pedido.estado != 'Solicitado': return redirect(url_for('main.ver_pedido', pedido_id=pedido_id))
    return render_template('recepcion_pedido.html', pedido=pedido)

@main_bp.route('/compra/<int:pedido_id>/procesar_recepcion', methods=['POST'])
@login_required
def procesar_recepcion(pedido_id):
    pedido = PedidoCompra.query.get_or_404(pedido_id)
    if pedido.estado != 'Solicitado': return redirect(url_for('main.ver_pedido', pedido_id=pedido_id))
    try:
        pedido.estado = 'Recibido'
        pedido.fecha_recepcion = datetime.utcnow().date()
        for detalle in pedido.detalles:
            key_form = f"recibido_{detalle.id}"
            cantidad_real = float(request.form.get(key_form, 0))
            detalle.cantidad_recibida = cantidad_real
            if cantidad_real > 0:
                detalle.insumo.cantidad_actual += cantidad_real
                nuevo_lote = LoteInsumo(
                    insumo_id=detalle.insumo_id, pedido_id=pedido.id, fecha_compra=pedido.fecha_recepcion,
                    cantidad_inicial=cantidad_real, cantidad_actual=cantidad_real, costo_unitario=detalle.precio_unitario
                )
                db.session.add(nuevo_lote)
                kardex = MovimientoInventario(
                    tipo_movimiento='Compra (Recepción)', cantidad=cantidad_real, costo_unitario=detalle.precio_unitario,
                    referencia=f"Pedido #{pedido.numero_orden}", insumo_id=detalle.insumo_id
                )
                db.session.add(kardex)
        db.session.commit()
        flash('Recepción registrada.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error: {e}', 'danger')
    return redirect(url_for('main.ver_pedido', pedido_id=pedido_id))


# ==================================================
# 5. MÓDULO DE PRODUCCIÓN (REFACTORIZADO)
# ==================================================

@main_bp.route('/produccion/especies')
@login_required
def lista_especies():
    especies = Especie.query.all()
    return render_template('produccion/lista_especies.html', especies=especies)

@main_bp.route('/produccion/especie/nueva', methods=['GET', 'POST'])
@login_required
def nueva_especie():
    if request.method == 'POST':
        nombre_comun = request.form.get('nombre_comun')
        nombre_cientifico = request.form.get('nombre_cientifico')
        dias_ciclo = request.form.get('dias_ciclo')
        
        # --- CAPTURAR FICHA TÉCNICA (AHORA EN ESPECIE) ---
        detalles_cuidado = request.form.get('detalles_cuidado')

        try:
            nueva = Especie(
                nombre_comun=nombre_comun, nombre_cientifico=nombre_cientifico,
                dias_ciclo_estimado=int(dias_ciclo) if dias_ciclo else 0,
                detalles_cuidado=detalles_cuidado # Guardamos aquí
            )
            db.session.add(nueva)
            db.session.commit()
            flash('Especie y ficha técnica registradas.', 'success')
            return redirect(url_for('main.lista_especies'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error: {e}', 'danger')
    return render_template('produccion/nueva_especie.html')

# --- RUTA PARA EDITAR FICHA TÉCNICA (AHORA EDITA LA ESPECIE) ---
@main_bp.route('/produccion/especie/editar_ficha/<int:especie_id>', methods=['POST'])
@login_required
def editar_ficha_especie(especie_id):
    especie = Especie.query.get_or_404(especie_id)
    # Redireccionamos al lote desde donde se llamó (opcional, para UX)
    lote_id_origen = request.args.get('lote_id') 
    
    try:
        especie.detalles_cuidado = request.form.get('detalles_cuidado')
        db.session.commit()
        flash('Ficha técnica de la especie actualizada. Todos los lotes reflejarán este cambio.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al actualizar ficha: {e}', 'danger')
    
    if lote_id_origen:
        return redirect(url_for('main.ver_lote', lote_id=lote_id_origen))
    return redirect(url_for('main.lista_especies'))


@main_bp.route('/produccion/lotes')
@login_required
def lista_lotes():
    query_str = request.args.get('q', '').strip()
    es_ajax = request.args.get('ajax') == '1' # Detectar petición dinámica
    
    # Query Base
    query = LoteProduccion.query.join(Especie)
    
    if query_str:
        # Filtro de búsqueda avanzado
        query = query.filter(or_(
            LoteProduccion.codigo_lote.ilike(f'%{query_str}%'),
            LoteProduccion.ubicacion.ilike(f'%{query_str}%'),
            Especie.nombre_comun.ilike(f'%{query_str}%'),
            Especie.nombre_cientifico.ilike(f'%{query_str}%')
        ))
    
    # Ordenamiento por defecto
    lotes = query.order_by(LoteProduccion.fecha_siembra.desc()).all()
    today = datetime.utcnow().date()
    
    # --- RESPUESTA DINÁMICA ---
    if es_ajax:
        # CORREGIDO: Apunta a la carpeta 'parciales' global
        return render_template('parciales/items_lotes.html', lotes=lotes, today=today)
    
    # Si es normal, devolvemos la página completa
    return render_template('produccion/lista_lotes.html', lotes=lotes, today=today)

@main_bp.route('/produccion/lote/nuevo', methods=['GET', 'POST'])
@login_required
def nuevo_lote():
    especies = Especie.query.all()
    if request.method == 'POST':
        try:
            especie_id = int(request.form.get('especie_id'))
            cantidad = int(request.form.get('cantidad_sembrada'))
            ubicacion = request.form.get('ubicacion').strip()
            
            lote_existente = LoteProduccion.query.filter(
                LoteProduccion.especie_id == especie_id,
                LoteProduccion.ubicacion == ubicacion,
                LoteProduccion.estado == 'En Crecimiento'
            ).first()

            if lote_existente:
                lote_existente.cantidad_sembrada += cantidad
                lote_existente.cantidad_actual += cantidad
                db.session.commit()
                flash(f'Se agregaron {cantidad} plantas al lote existente en {ubicacion}.', 'info')
                return redirect(url_for('main.ver_lote', lote_id=lote_existente.id))
            
            else:
                codigo = f"LOTE-{int(datetime.now().timestamp())}" 
                nuevo = LoteProduccion(
                    codigo_lote=codigo, especie_id=especie_id, cantidad_sembrada=cantidad,
                    cantidad_actual=cantidad, ubicacion=ubicacion, estado='En Crecimiento', costo_total=0.0
                )
                db.session.add(nuevo)
                db.session.commit()
                flash('Nuevo lote iniciado correctamente.', 'success')
                return redirect(url_for('main.ver_lote', lote_id=nuevo.id))

        except Exception as e:
            db.session.rollback()
            flash(f'Error: {e}', 'danger')
            
    return render_template('produccion/nuevo_lote.html', especies=especies)

@main_bp.route('/produccion/lote/<int:lote_id>')
@login_required
def ver_lote(lote_id):
    lote = LoteProduccion.query.get_or_404(lote_id)
    insumos = Insumo.query.order_by(Insumo.nombre).all()
    return render_template('produccion/ver_lote.html', lote=lote, insumos=insumos)

@main_bp.route('/produccion/lote/eliminar/<int:lote_id>', methods=['POST'])
@login_required
def eliminar_lote(lote_id):
    lote = LoteProduccion.query.get_or_404(lote_id)
    if lote.ventas_realizadas:
        flash('No se puede eliminar este lote porque ya tiene ventas registradas.', 'warning')
        return redirect(url_for('main.ver_lote', lote_id=lote_id))

    try:
        Labores = LaborCampo.query.filter_by(lote_id=lote.id).all()
        for l in Labores:
            for c in l.consumos: db.session.delete(c)
            db.session.delete(l)
        db.session.delete(lote)
        db.session.commit()
        flash('Lote eliminado correctamente.', 'success')
        return redirect(url_for('main.lista_lotes'))
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar: {e}', 'danger')
        return redirect(url_for('main.ver_lote', lote_id=lote_id))

@main_bp.route('/produccion/lote/ajustar/<int:lote_id>', methods=['POST'])
@login_required
def ajustar_stock_lote(lote_id):
    lote = LoteProduccion.query.get_or_404(lote_id)
    try:
        nueva_cantidad = int(request.form.get('nueva_cantidad'))
        motivo = request.form.get('motivo')
        if nueva_cantidad < 0: raise ValueError("La cantidad no puede ser negativa")
        diferencia = nueva_cantidad - lote.cantidad_actual
        lote.cantidad_actual = nueva_cantidad
        labor_ajuste = LaborCampo(lote_id=lote.id, tipo_labor='Ajuste Inventario', descripcion=f"Ajuste manual: {diferencia}. Motivo: {motivo}", usuario_id=current_user.id, fecha=datetime.utcnow().date())
        db.session.add(labor_ajuste)
        if nueva_cantidad == 0: lote.estado = 'Finalizado'
        db.session.commit()
        flash(f'Stock ajustado correctamente.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al ajustar stock: {e}', 'danger')
    return redirect(url_for('main.ver_lote', lote_id=lote_id))

@main_bp.route('/produccion/labor/guardar', methods=['POST'])
@login_required
def registrar_labor():
    lote_id = request.form.get('lote_id')
    lote = LoteProduccion.query.get_or_404(lote_id)
    tipo_labor = request.form.get('tipo_labor')
    descripcion = request.form.get('descripcion')
    insumo_id = request.form.get('insumo_id')
    cantidad_insumo = float(request.form.get('cantidad_insumo') or 0)
    try:
        labor = LaborCampo(lote_id=lote.id, tipo_labor=tipo_labor, descripcion=descripcion, usuario_id=current_user.id, fecha=datetime.utcnow().date())
        db.session.add(labor)
        db.session.flush() 
        costo_agregado = 0.0
        if insumo_id and cantidad_insumo > 0:
            insumo = Insumo.query.get(insumo_id)
            if insumo.cantidad_actual < cantidad_insumo: raise Exception(f"Stock insuficiente de {insumo.nombre}.")
            # FIFO logic simplificada para brevedad
            insumo.cantidad_actual -= cantidad_insumo
            consumo = ConsumoInsumo(labor_id=labor.id, insumo_id=insumo.id, cantidad=cantidad_insumo, costo_unitario_calculado=insumo.costo_promedio, subtotal=cantidad_insumo*insumo.costo_promedio)
            db.session.add(consumo)
            costo_agregado = consumo.subtotal
        lote.costo_insumos += costo_agregado
        lote.costo_total += costo_agregado
        db.session.commit()
        flash(f'Labor registrada.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al registrar: {e}', 'danger')
    return redirect(url_for('main.ver_lote', lote_id=lote_id))

@main_bp.route('/produccion/labor/editar/<int:labor_id>', methods=['POST'])
@login_required
def editar_labor(labor_id):
    labor = LaborCampo.query.get_or_404(labor_id)
    try:
        labor.tipo_labor = request.form.get('tipo_labor')
        labor.descripcion = request.form.get('descripcion')
        db.session.commit()
        flash('Actualizado.', 'success')
    except: db.session.rollback()
    return redirect(url_for('main.ver_lote', lote_id=labor.lote_id))

@main_bp.route('/produccion/labor/eliminar/<int:labor_id>', methods=['POST'])
@login_required
def eliminar_labor(labor_id):
    labor = LaborCampo.query.get_or_404(labor_id)
    lote = labor.lote
    try:
        for c in labor.consumos:
            c.insumo.cantidad_actual += c.cantidad
            lote.costo_insumos -= c.subtotal
            lote.costo_total -= c.subtotal
            db.session.delete(c)
        db.session.delete(labor)
        db.session.commit()
        flash('Labor eliminada.', 'success')
    except: db.session.rollback()
    return redirect(url_for('main.ver_lote', lote_id=lote.id))


# ==================================================
# 6. MÓDULO DE VENTAS Y CLIENTES
# ==================================================

# --- GESTIÓN DE CLIENTES ---
@main_bp.route('/clientes')
@login_required
def lista_clientes():
    q = request.args.get('q', '').strip()
    query = Cliente.query
    if q: query = query.filter(or_(Cliente.nombre.ilike(f'%{q}%'), Cliente.documento.ilike(f'%{q}%')))
    return render_template('ventas/lista_clientes.html', clientes=query.all(), search_query=q)

@main_bp.route('/cliente/nuevo', methods=['GET', 'POST'])
@login_required
def nuevo_cliente():
    if request.method == 'POST':
        try:
            c = Cliente(
                nombre=request.form.get('nombre'),
                documento=request.form.get('documento'),
                telefono=request.form.get('telefono'),
                email=request.form.get('email'),
                direccion=request.form.get('direccion')
            )
            db.session.add(c)
            db.session.commit()
            flash('Cliente registrado.', 'success')
            return redirect(url_for('main.lista_clientes'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error: {e}', 'danger')
    return render_template('ventas/nuevo_cliente.html')

# --- GESTIÓN DE VENTAS ---
@main_bp.route('/ventas')
@login_required
def lista_ventas():
    ventas = Venta.query.order_by(Venta.fecha.desc()).all()
    return render_template('ventas/lista_ventas.html', ventas=ventas)

@main_bp.route('/venta/nueva', methods=['GET', 'POST'])
@login_required
def nueva_venta():
    # 1. Buscar o Crear "Cliente Mostrador" por defecto
    cliente_defecto = Cliente.query.filter_by(nombre='Cliente Mostrador').first()
    if not cliente_defecto:
        try:
            cliente_defecto = Cliente(nombre='Cliente Mostrador', documento='222222222', direccion='Local', email='ventas@local.com')
            db.session.add(cliente_defecto)
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            flash(f'Error al crear cliente por defecto: {e}', 'danger')
            return redirect(url_for('main.lista_ventas'))

    # 2. Crear Venta Borrador inmediatamente
    try:
        v = Venta(
            numero_factura=f"FAC-{int(datetime.now().timestamp())}",
            cliente_id=cliente_defecto.id,
            usuario_id=current_user.id,
            estado='Borrador'
        )
        db.session.add(v)
        db.session.commit()
        # Redirigir directo a agregar items
        return redirect(url_for('main.ver_venta', venta_id=v.id))
    except Exception as e:
        db.session.rollback()
        flash(f'Error al iniciar venta: {e}', 'danger')
        return redirect(url_for('main.lista_ventas'))

@main_bp.route('/venta/<int:venta_id>')
@login_required
def ver_venta(venta_id):
    venta = Venta.query.get_or_404(venta_id)
    # Solo lotes que tengan plantas disponibles
    lotes_disponibles = LoteProduccion.query.filter(LoteProduccion.cantidad_actual > 0, LoteProduccion.estado != 'Cancelado').all()
    # Clientes para el modal de cambio
    clientes = Cliente.query.order_by(Cliente.nombre).all()
    return render_template('ventas/ver_venta.html', venta=venta, lotes=lotes_disponibles, clientes=clientes)

@main_bp.route('/venta/<int:venta_id>/cambiar_cliente', methods=['POST'])
@login_required
def cambiar_cliente_venta(venta_id):
    venta = Venta.query.get_or_404(venta_id)
    if venta.estado != 'Borrador':
        return redirect(url_for('main.ver_venta', venta_id=venta_id))
    
    try:
        nuevo_cliente_id = request.form.get('cliente_id')
        if nuevo_cliente_id:
            venta.cliente_id = int(nuevo_cliente_id)
            db.session.commit()
            flash('Cliente actualizado correctamente.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al cambiar cliente: {e}', 'danger')
        
    return redirect(url_for('main.ver_venta', venta_id=venta_id))

@main_bp.route('/venta/<int:venta_id>/agregar', methods=['POST'])
@login_required
def agregar_item_venta(venta_id):
    venta = Venta.query.get_or_404(venta_id)
    if venta.estado != 'Borrador': return redirect(url_for('main.ver_venta', venta_id=venta_id))
        
    try:
        lote_id = request.form.get('lote_id')
        cantidad = int(request.form.get('cantidad'))
        precio_venta = float(request.form.get('precio_unitario'))
        
        lote = LoteProduccion.query.get(lote_id)
        if lote.cantidad_actual < cantidad:
            flash(f'Stock insuficiente en lote {lote.codigo_lote}.', 'warning')
            return redirect(url_for('main.ver_venta', venta_id=venta_id))
            
        costo_prod_unitario = 0
        if lote.cantidad_actual > 0:
            costo_prod_unitario = lote.costo_total / lote.cantidad_actual
            
        subtotal = cantidad * precio_venta
        ganancia = subtotal - (cantidad * costo_prod_unitario)
        
        detalle = DetalleVenta(
            venta_id=venta.id, lote_id=lote.id, cantidad=cantidad,
            precio_venta_unitario=precio_venta, costo_produccion_unitario=costo_prod_unitario,
            subtotal=subtotal, ganancia=ganancia
        )
        venta.total += subtotal
        db.session.add(detalle)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        flash(f'Error: {e}', 'danger')
        
    return redirect(url_for('main.ver_venta', venta_id=venta_id))

@main_bp.route('/venta/<int:venta_id>/finalizar', methods=['POST'])
@login_required
def finalizar_venta(venta_id):
    venta = Venta.query.get_or_404(venta_id)
    if venta.estado != 'Borrador': return redirect(url_for('main.ver_venta', venta_id=venta_id))
    
    try:
        for d in venta.detalles:
            lote = d.lote_origen
            if lote.cantidad_actual < d.cantidad:
                raise Exception(f"El lote {lote.codigo_lote} ya no tiene stock.")
            
            lote.cantidad_actual -= d.cantidad
            costo_salida = d.cantidad * d.costo_produccion_unitario
            lote.costo_total -= costo_salida
            
            if lote.cantidad_actual == 0: lote.estado = 'Finalizado'
                
        venta.estado = 'Finalizada'
        db.session.commit()
        flash('Venta registrada con éxito.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al finalizar venta: {e}', 'danger')
        
    return redirect(url_for('main.ver_venta', venta_id=venta_id))