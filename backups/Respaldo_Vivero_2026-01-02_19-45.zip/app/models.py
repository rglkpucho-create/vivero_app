from .extensions import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

# ==========================================
# 1. USUARIOS Y ROLES
# ==========================================

class Rol(db.Model):
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50), unique=True, nullable=False)
    usuarios = db.relationship('Usuario', backref='rol', lazy=True)

class Usuario(UserMixin, db.Model):
    __tablename__ = 'usuarios'
    id = db.Column(db.Integer, primary_key=True)
    nombre_completo = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    telefono = db.Column(db.String(20))
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    rol_id = db.Column(db.Integer, db.ForeignKey('roles.id'))

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

# ==========================================
# 2. INVENTARIO E INSUMOS
# ==========================================

class Proveedor(db.Model):
    __tablename__ = 'proveedores'
    id = db.Column(db.Integer, primary_key=True)
    razon_social = db.Column(db.String(100), nullable=False)
    nit_rut = db.Column(db.String(20))
    contacto_nombre = db.Column(db.String(100))
    telefono = db.Column(db.String(20))
    email = db.Column(db.String(100))
    direccion = db.Column(db.String(200))
    pedidos = db.relationship('PedidoCompra', backref='proveedor', lazy=True)

class UnidadMedida(db.Model):
    __tablename__ = 'unidades_medida'
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50), nullable=False)
    abreviatura = db.Column(db.String(10), nullable=False)
    insumos = db.relationship('Insumo', backref='unidad', lazy=True)

class Insumo(db.Model):
    __tablename__ = 'insumos'
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    tipo = db.Column(db.String(50))  # Fertilizante, Herramienta, etc.
    stock_minimo = db.Column(db.Float, default=0.0)
    cantidad_actual = db.Column(db.Float, default=0.0)
    costo_promedio = db.Column(db.Float, default=0.0)
    unidad_medida_id = db.Column(db.Integer, db.ForeignKey('unidades_medida.id'))
    
    lotes = db.relationship('LoteInsumo', backref='insumo', lazy=True)
    movimientos = db.relationship('MovimientoInventario', backref='insumo', lazy=True)

class LoteInsumo(db.Model):
    """FIFO: Rastrea lotes de insumos comprados a diferentes precios"""
    __tablename__ = 'lotes_insumo'
    id = db.Column(db.Integer, primary_key=True)
    insumo_id = db.Column(db.Integer, db.ForeignKey('insumos.id'), nullable=False)
    pedido_id = db.Column(db.Integer, db.ForeignKey('pedidos_compra.id'))
    fecha_compra = db.Column(db.Date, default=datetime.utcnow)
    cantidad_inicial = db.Column(db.Float, nullable=False)
    cantidad_actual = db.Column(db.Float, nullable=False)
    costo_unitario = db.Column(db.Float, nullable=False)
    activo = db.Column(db.Boolean, default=True)

class MovimientoInventario(db.Model):
    __tablename__ = 'movimientos_inventario'
    id = db.Column(db.Integer, primary_key=True)
    insumo_id = db.Column(db.Integer, db.ForeignKey('insumos.id'), nullable=False)
    tipo_movimiento = db.Column(db.String(50)) # Compra, Consumo, Ajuste
    cantidad = db.Column(db.Float, nullable=False)
    costo_unitario = db.Column(db.Float)
    fecha = db.Column(db.DateTime, default=datetime.utcnow)
    referencia = db.Column(db.String(100)) # ID Pedido, ID Lote Producción, etc.

# ==========================================
# 3. COMPRAS
# ==========================================

class PedidoCompra(db.Model):
    __tablename__ = 'pedidos_compra'
    id = db.Column(db.Integer, primary_key=True)
    numero_orden = db.Column(db.String(20), unique=True, nullable=False)
    proveedor_id = db.Column(db.Integer, db.ForeignKey('proveedores.id'), nullable=False)
    fecha_solicitud = db.Column(db.Date, nullable=False)
    fecha_recepcion = db.Column(db.Date)
    estado = db.Column(db.String(20), default='Solicitado') # Solicitado, Recibido, Cancelado
    total_estimado = db.Column(db.Float, default=0.0)
    
    detalles = db.relationship('DetallePedidoCompra', backref='pedido', lazy=True, cascade="all, delete-orphan")

class DetallePedidoCompra(db.Model):
    __tablename__ = 'detalles_pedido_compra'
    id = db.Column(db.Integer, primary_key=True)
    pedido_id = db.Column(db.Integer, db.ForeignKey('pedidos_compra.id'), nullable=False)
    insumo_id = db.Column(db.Integer, db.ForeignKey('insumos.id'), nullable=False)
    cantidad_solicitada = db.Column(db.Float, nullable=False)
    cantidad_recibida = db.Column(db.Float, default=0.0)
    precio_unitario = db.Column(db.Float, nullable=False)
    
    insumo = db.relationship('Insumo')

# ==========================================
# 4. PRODUCCIÓN (CULTIVOS)
# ==========================================

class Especie(db.Model):
    __tablename__ = 'especies'
    id = db.Column(db.Integer, primary_key=True)
    nombre_comun = db.Column(db.String(100), nullable=False)
    nombre_cientifico = db.Column(db.String(100))
    dias_ciclo_estimado = db.Column(db.Integer)
    
    # --- CAMBIO IMPORTANTE: FICHA TÉCNICA CENTRALIZADA ---
    # La ficha técnica ahora pertenece a la especie, no al lote.
    detalles_cuidado = db.Column(db.Text) 
    
    lotes = db.relationship('LoteProduccion', backref='especie', lazy=True)

class LoteProduccion(db.Model):
    __tablename__ = 'lotes_produccion'
    id = db.Column(db.Integer, primary_key=True)
    codigo_lote = db.Column(db.String(50), unique=True, nullable=False)
    especie_id = db.Column(db.Integer, db.ForeignKey('especies.id'), nullable=False)
    
    cantidad_sembrada = db.Column(db.Integer, nullable=False)
    cantidad_actual = db.Column(db.Integer, nullable=False)
    ubicacion = db.Column(db.String(100))
    estado = db.Column(db.String(20), default='En Crecimiento') # En Crecimiento, Finalizado, Cancelado
    fecha_siembra = db.Column(db.Date, default=datetime.utcnow)
    
    # Costos acumulados
    costo_total = db.Column(db.Float, default=0.0)
    costo_insumos = db.Column(db.Float, default=0.0)
    
    # NOTA: Se eliminó 'detalles_cuidado' de aquí.

    # Relaciones
    labores = db.relationship('LaborCampo', backref='lote', lazy=True, cascade="all, delete-orphan")
    ventas = db.relationship('DetalleVenta', backref='lote_origen', lazy=True)

    @property
    def ventas_realizadas(self):
        return len(self.ventas) > 0

class LaborCampo(db.Model):
    __tablename__ = 'labores_campo'
    id = db.Column(db.Integer, primary_key=True)
    lote_id = db.Column(db.Integer, db.ForeignKey('lotes_produccion.id'), nullable=False)
    tipo_labor = db.Column(db.String(50), nullable=False) # Riego, Poda, etc.
    descripcion = db.Column(db.Text)
    fecha = db.Column(db.Date, default=datetime.utcnow)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'))
    
    consumos = db.relationship('ConsumoInsumo', backref='labor', lazy=True, cascade="all, delete-orphan")
    usuario = db.relationship('Usuario')

class ConsumoInsumo(db.Model):
    __tablename__ = 'consumos_insumo'
    id = db.Column(db.Integer, primary_key=True)
    labor_id = db.Column(db.Integer, db.ForeignKey('labores_campo.id'), nullable=False)
    insumo_id = db.Column(db.Integer, db.ForeignKey('insumos.id'), nullable=False)
    cantidad = db.Column(db.Float, nullable=False)
    costo_unitario_calculado = db.Column(db.Float, nullable=False)
    subtotal = db.Column(db.Float, nullable=False)
    
    insumo = db.relationship('Insumo')

# ==========================================
# 5. VENTAS
# ==========================================

class Cliente(db.Model):
    __tablename__ = 'clientes'
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    documento = db.Column(db.String(20))
    telefono = db.Column(db.String(20))
    email = db.Column(db.String(100))
    direccion = db.Column(db.String(200))
    
    ventas = db.relationship('Venta', backref='cliente', lazy=True)

class Venta(db.Model):
    __tablename__ = 'ventas'
    id = db.Column(db.Integer, primary_key=True)
    numero_factura = db.Column(db.String(50), unique=True, nullable=False)
    cliente_id = db.Column(db.Integer, db.ForeignKey('clientes.id'), nullable=False)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'))
    fecha = db.Column(db.DateTime, default=datetime.utcnow)
    total = db.Column(db.Float, default=0.0)
    estado = db.Column(db.String(20), default='Borrador') # Borrador, Finalizada, Anulada

    detalles = db.relationship('DetalleVenta', backref='venta', lazy=True, cascade="all, delete-orphan")
    usuario = db.relationship('Usuario')

class DetalleVenta(db.Model):
    __tablename__ = 'detalles_venta'
    id = db.Column(db.Integer, primary_key=True)
    venta_id = db.Column(db.Integer, db.ForeignKey('ventas.id'), nullable=False)
    lote_id = db.Column(db.Integer, db.ForeignKey('lotes_produccion.id'), nullable=False)
    
    cantidad = db.Column(db.Integer, nullable=False)
    precio_venta_unitario = db.Column(db.Float, nullable=False)
    costo_produccion_unitario = db.Column(db.Float, default=0.0)
    subtotal = db.Column(db.Float, nullable=False)
    ganancia = db.Column(db.Float, default=0.0)