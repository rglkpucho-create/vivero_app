-- MySQL dump 10.13  Distrib 8.4.3, for Win64 (x86_64)
--
-- Host: localhost    Database: ecosistem_v4
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `documento` varchar(20) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (3,'Cliente Mostrador','222222','000',NULL,'Local'),(4,'Juan Pérez','1098765432','3201112233',NULL,'Calle 123');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `documento` varchar(50) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'Ana Guerrero','37330774','3189973959','anaguerrero91@gmail.com','Bucaramanga'),(2,'Cliente Mostrador','222222222',NULL,'ventas@local.com','Local');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consumo_animal`
--

DROP TABLE IF EXISTS `consumo_animal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consumo_animal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `lote_animal_id` int DEFAULT NULL,
  `insumo_id` int DEFAULT NULL,
  `cantidad` float DEFAULT NULL,
  `costo_calculado` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lote_animal_id` (`lote_animal_id`),
  KEY `insumo_id` (`insumo_id`),
  CONSTRAINT `consumo_animal_ibfk_1` FOREIGN KEY (`lote_animal_id`) REFERENCES `lote_animal` (`id`),
  CONSTRAINT `consumo_animal_ibfk_2` FOREIGN KEY (`insumo_id`) REFERENCES `insumo` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumo_animal`
--

LOCK TABLES `consumo_animal` WRITE;
/*!40000 ALTER TABLE `consumo_animal` DISABLE KEYS */;
/*!40000 ALTER TABLE `consumo_animal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consumo_insumo`
--

DROP TABLE IF EXISTS `consumo_insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consumo_insumo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `labor_id` int DEFAULT NULL,
  `insumo_id` int DEFAULT NULL,
  `cantidad` float DEFAULT NULL,
  `subtotal` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `labor_id` (`labor_id`),
  KEY `insumo_id` (`insumo_id`),
  CONSTRAINT `consumo_insumo_ibfk_1` FOREIGN KEY (`labor_id`) REFERENCES `labor_campo` (`id`),
  CONSTRAINT `consumo_insumo_ibfk_2` FOREIGN KEY (`insumo_id`) REFERENCES `insumo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumo_insumo`
--

LOCK TABLES `consumo_insumo` WRITE;
/*!40000 ALTER TABLE `consumo_insumo` DISABLE KEYS */;
INSERT INTO `consumo_insumo` VALUES (13,13,11,60,250000),(14,14,11,6,30000),(15,15,45,10,100000);
/*!40000 ALTER TABLE `consumo_insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consumos_insumo`
--

DROP TABLE IF EXISTS `consumos_insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consumos_insumo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `labor_id` int NOT NULL,
  `insumo_id` int NOT NULL,
  `cantidad` float NOT NULL,
  `costo_unitario_calculado` float NOT NULL,
  `subtotal` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `labor_id` (`labor_id`),
  KEY `insumo_id` (`insumo_id`),
  CONSTRAINT `consumos_insumo_ibfk_1` FOREIGN KEY (`labor_id`) REFERENCES `labores_campo` (`id`),
  CONSTRAINT `consumos_insumo_ibfk_2` FOREIGN KEY (`insumo_id`) REFERENCES `insumos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumos_insumo`
--

LOCK TABLES `consumos_insumo` WRITE;
/*!40000 ALTER TABLE `consumos_insumo` DISABLE KEYS */;
INSERT INTO `consumos_insumo` VALUES (5,14,1,10,120,1200),(6,15,1,20,120,2400),(7,16,1,210,167.619,35200);
/*!40000 ALTER TABLE `consumos_insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_pedido_compra`
--

DROP TABLE IF EXISTS `detalle_pedido_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_pedido_compra` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pedido_id` int DEFAULT NULL,
  `insumo_id` int DEFAULT NULL,
  `cantidad_solicitada` float DEFAULT NULL,
  `cantidad_recibida` float DEFAULT NULL,
  `precio_unitario` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pedido_id` (`pedido_id`),
  KEY `insumo_id` (`insumo_id`),
  CONSTRAINT `detalle_pedido_compra_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedido_compra` (`id`),
  CONSTRAINT `detalle_pedido_compra_ibfk_2` FOREIGN KEY (`insumo_id`) REFERENCES `insumo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_pedido_compra`
--

LOCK TABLES `detalle_pedido_compra` WRITE;
/*!40000 ALTER TABLE `detalle_pedido_compra` DISABLE KEYS */;
INSERT INTO `detalle_pedido_compra` VALUES (17,24,41,1,1,1000),(18,24,25,10,10,15000),(19,24,12,100,100,3000),(20,25,11,1,0,5000),(21,26,11,1,0,5000),(22,26,12,24,0,3000),(23,27,12,20,0,3000),(24,27,11,10,0,5000),(25,28,11,2,2,5000),(26,28,43,10,10,52000),(27,28,44,1,1,10000),(28,28,30,1,1,10000),(29,29,12,10,0,3000),(30,29,13,11,0,5000),(31,30,45,50,40,10000);
/*!40000 ALTER TABLE `detalle_pedido_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_venta`
--

DROP TABLE IF EXISTS `detalle_venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_venta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `venta_id` int DEFAULT NULL,
  `lote_id` int DEFAULT NULL,
  `insumo_id` int DEFAULT NULL,
  `cantidad` float DEFAULT NULL,
  `precio_venta_unitario` float DEFAULT NULL,
  `costo_produccion_unitario` float DEFAULT NULL,
  `subtotal` float DEFAULT NULL,
  `ganancia` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `venta_id` (`venta_id`),
  KEY `lote_id` (`lote_id`),
  KEY `insumo_id` (`insumo_id`),
  CONSTRAINT `detalle_venta_ibfk_1` FOREIGN KEY (`venta_id`) REFERENCES `venta` (`id`),
  CONSTRAINT `detalle_venta_ibfk_2` FOREIGN KEY (`lote_id`) REFERENCES `lote_produccion` (`id`),
  CONSTRAINT `detalle_venta_ibfk_3` FOREIGN KEY (`insumo_id`) REFERENCES `insumo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_venta`
--

LOCK TABLES `detalle_venta` WRITE;
/*!40000 ALTER TABLE `detalle_venta` DISABLE KEYS */;
INSERT INTO `detalle_venta` VALUES (3,14,NULL,11,1,6500,5000,6500,1500),(4,14,6,NULL,2,325,250,650,150),(5,14,6,NULL,1,325,250,325,75),(6,12,6,NULL,2,325,250,650,150),(7,12,NULL,11,2,6500,5000,13000,3000),(8,13,6,NULL,2,364,280.09,728,167.82),(9,13,NULL,11,2,6500,5000,13000,3000),(10,13,NULL,NULL,1,50000,0,50000,50000),(11,15,NULL,11,30,6500,5000,195000,45000);
/*!40000 ALTER TABLE `detalle_venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalles_pedido_compra`
--

DROP TABLE IF EXISTS `detalles_pedido_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalles_pedido_compra` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pedido_id` int NOT NULL,
  `insumo_id` int NOT NULL,
  `cantidad_solicitada` float NOT NULL,
  `cantidad_recibida` float DEFAULT NULL,
  `precio_unitario` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pedido_id` (`pedido_id`),
  KEY `insumo_id` (`insumo_id`),
  CONSTRAINT `detalles_pedido_compra_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos_compra` (`id`),
  CONSTRAINT `detalles_pedido_compra_ibfk_2` FOREIGN KEY (`insumo_id`) REFERENCES `insumos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalles_pedido_compra`
--

LOCK TABLES `detalles_pedido_compra` WRITE;
/*!40000 ALTER TABLE `detalles_pedido_compra` DISABLE KEYS */;
INSERT INTO `detalles_pedido_compra` VALUES (1,1,1,50,50,120),(2,2,1,200,200,100),(3,2,3,12,12,5000),(4,2,4,11,11,20000),(5,4,1,10,10,1500),(6,5,5,10,10,2000),(7,7,5,10,10,2400),(8,8,7,100,100,1000),(9,8,8,50,50,50000),(10,9,1,1000,1000,5000),(11,9,9,200,200,1000),(12,11,1,100,100,15000),(14,13,1,100,0,2500),(15,14,1,100,100,2500),(16,14,4,50,50,85000);
/*!40000 ALTER TABLE `detalles_pedido_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalles_venta`
--

DROP TABLE IF EXISTS `detalles_venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalles_venta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `venta_id` int NOT NULL,
  `lote_id` int NOT NULL,
  `cantidad` int NOT NULL,
  `precio_venta_unitario` float NOT NULL,
  `costo_produccion_unitario` float NOT NULL,
  `subtotal` float NOT NULL,
  `ganancia` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `venta_id` (`venta_id`),
  KEY `lote_id` (`lote_id`),
  CONSTRAINT `detalles_venta_ibfk_1` FOREIGN KEY (`venta_id`) REFERENCES `ventas` (`id`),
  CONSTRAINT `detalles_venta_ibfk_2` FOREIGN KEY (`lote_id`) REFERENCES `lotes_produccion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalles_venta`
--

LOCK TABLES `detalles_venta` WRITE;
/*!40000 ALTER TABLE `detalles_venta` DISABLE KEYS */;
INSERT INTO `detalles_venta` VALUES (3,13,8,1,1500,300,1500,1200);
/*!40000 ALTER TABLE `detalles_venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `especie`
--

DROP TABLE IF EXISTS `especie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `especie` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_comun` varchar(100) NOT NULL,
  `nombre_cientifico` varchar(100) DEFAULT NULL,
  `dias_ciclo_estimado` int DEFAULT NULL,
  `detalles_cuidado` text,
  `imagen_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `especie`
--

LOCK TABLES `especie` WRITE;
/*!40000 ALTER TABLE `especie` DISABLE KEYS */;
INSERT INTO `especie` VALUES (18,'Tomate Chonto',NULL,90,'None🌿 Características de la Planta\r\n- Crecimiento: Indeterminado, con alto cuaje (formación de frutos)\r\n- Plantulación: 25 – 35 días\r\n- Inicio de cosecha: 70 – 90 días después del trasplante\r\n- Días de germinación: ~8 días\r\n\r\n🍅 Características del Fruto\r\n- Forma: Redondo, semi achatado en los polos\r\n- Peso promedio: 150 g por fruto\r\n- Coloración: Roja intensa\r\n- Uso principal: Consumo fresco y preparación de salsas/aliños\r\n📊 Datos de Siembra\r\n- Distancia entre plantas: 40 – 50 cm\r\n- Distancia entre hileras/surcos: 80 cm – 1.20 m\r\n- Densidad de siembra: 18.000 – 22.000 plantas/ha\r\n- Semillas por gramo: 250 – 340\r\n- Cantidad de semilla por ha: 200 – 300 g\r\n\r\n📈 Rendimiento y Producción\r\n- Producción estimada: 25 – 40 toneladas/ha\r\n- Ciclo a cosecha: 70 – 90 días\r\n\r\n🌾 Manejo Agronómico\r\n- Fertilización: Aplicar elementos mayores y menores según análisis de suelo\r\n- Control de malezas: Manual y químico\r\n- Resistencia: Buena tolerancia a enfermedades como Verticillium\r\n\r\n\r\n','uploads/especies/1767853326_tomchont.webp'),(19,'Lechuga Batavia','Lactuca sativa',60,'Clima frío a templado. Riego constante para evitar sabor amargo. Cosecha rápida. Ideal para sistemas hidropónicos o suelo suelto.',NULL),(20,'Zanahoria','Daucus carota',100,'Suelo profundo y suelto (arenoso) es vital para que no salga deforme. Riego regular. Clima fresco.',NULL),(21,'Cebolla de Rama (Junca)','Allium fistulosum',120,'Muy resistente. Prefiere clima frío o templado. Requiere aporque (cubrir base con tierra) para blanquear el tallo. Riego moderado.',NULL),(22,'Pimentón','Capsicum annuum',110,'Clima cálido. Necesita mucho sol. Riego moderado. Tutorado recomendado para soportar peso de frutos.','uploads/especies/1767853365_Pimenton.webp'),(23,'Cilantro','Coriandrum sativum',45,'Ciclo muy corto. Clima templado. Riego ligero diario. Se puede resernbrar cada 2 semanas para tener siempre fresco.','uploads/especies/1767853351_Cilantro.webp'),(24,'Maíz Dulce','Zea mays',120,'Requiere mucho sol y agua, especialmente en floración. Suelo rico en nitrógeno. Sembrar en bloques para mejorar polinización.',NULL),(25,'Lulo','Solanum quitoense',240,'Clima fresco y húmedo (bosque niebla). Sombra parcial. Suelo rico en materia orgánica. Cuidado con nematodos en la raíz.',NULL),(26,'Mora de Castilla','Rubus glaucus',270,'Clima frío. Requiere tutorado (espardera). Poda constante de ramas viejas para estimular producción. Riego frecuente.',NULL),(27,'Maracuyá','Passiflora edulis',180,'Clima cálido. Trepadora vigorosa, requiere espaldera o glorieta. Mucho sol. Polinización manual ayuda a cuajar frutos.',NULL),(28,'Aguacate Hass','Persea americana',730,'Suelo MUY bien drenado (no tolera encharcamiento). Clima templado a frío moderado. Poda de formación necesaria.','uploads/especies/1767853383_Aguacate_Hass.webp'),(29,'Limón Tahití','Citrus latifolia',540,'Clima cálido a templado. Riego abundante. Fertilización rica en microelementos (Zinc, Magnesio). Poda de limpieza.',NULL),(30,'Albahaca','Ocimum basilicum',60,'Clima templado/cálido. Mucha luz pero no sol directo intenso todo el día. Riego en la base, no mojar hojas. Podar flores para alargar vida.',NULL),(31,'Menta / Hierbabuena','Mentha spicata',90,'Muy invasiva (mejor en maceta o controlada). Clima templado. Riego frecuente, le gusta la humedad. Sombra parcial tolerada.',NULL),(32,'Romero','Salvia rosmarinus',150,'Planta leñosa resistente. Poco riego (tolera sequía). Mucho sol. Suelo arenoso/drenado. Cosecha continua podando ramas.',NULL),(35,'Lengua de suegra','Sansevieria trifasciata)',150,'Requerimientos de cultivo\r\n- Luz: Tolera poca luz, pero crece mejor en semisombra o luz indirecta.\r\n- Riego: Escaso; dejar secar el sustrato entre riegos. Es sensible al exceso de agua.\r\n- Suelo: Bien drenado, arenoso o con mezcla para cactus.\r\n- Temperatura: Óptima entre 15–30 °C. No tolera heladas.\r\n- Mantenimiento: Muy bajo, ideal para principiantes.\r\n\r\nUsos\r\n- Decorativo: Muy popular en hogares y oficinas por su aspecto exótico.\r\n- Purificación del aire: Estudios la reconocen como planta que filtra toxinas como benceno y formaldehído.\r\n- Cultural: En tradiciones afrobrasileñas (candomblé, umbanda) se considera protectora contra energías negativas.\r\n\r\n\r\n','uploads/especies/1767934194_lengua_de_suegra.webp');
/*!40000 ALTER TABLE `especie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `especies`
--

DROP TABLE IF EXISTS `especies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `especies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_cientifico` varchar(100) DEFAULT NULL,
  `nombre_comun` varchar(100) NOT NULL,
  `familia` varchar(100) DEFAULT NULL,
  `foto_referencia` varchar(200) DEFAULT NULL,
  `ficha_tecnica` text,
  `dias_ciclo_estimado` int DEFAULT '0',
  `detalles_cuidado` text,
  `imagen_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre_cientifico` (`nombre_cientifico`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `especies`
--

LOCK TABLES `especies` WRITE;
/*!40000 ALTER TABLE `especies` DISABLE KEYS */;
INSERT INTO `especies` VALUES (1,'Musa paradisiaca','Plátano',NULL,NULL,NULL,365,'🍌 **Manejo del Cultivo:**\r\nClima:** Tropical húmedo, temperatura promedio 26°C. Altitud 0-1200 msnm.\r\nSuelo:** Franco-arenoso a franco-arcilloso, rico en materia orgánica. Buen drenaje es vital.\r\n- **Riego:** Alta demanda hídrica. Déficit causa racimos pequeños.\r\n- **Labores:** Deshije constante (dejar solo madre, hijo, nieto), deshoje sanitario semanal.\r\n- **Fertilización:** Alta demanda de Potasio (K) para llenado de fruto.','uploads/especies/1767681785_un-racimo-de-platanos-verdes.webp'),(2,'mango','Mango',NULL,NULL,NULL,120,NULL,NULL),(3,'Musa AAB Simmonds','Plátano Dominico Hartón',NULL,NULL,NULL,365,'CULTIVO DE PLÁTANO (Musa AAB)\n\n1. CLIMA Y SUELO\n- Altura: 0 - 1.200 msnm.\n- Temp: 26°C - 30°C.\n- Suelo: Franco-arenoso, rico en materia orgánica.\n\n2. MANEJO CULTURAL\n- Deshije: Seleccionar un solo sucesor (\"hijo\") cada 8 semanas.\n- Deshoje: Semanal. Retirar hojas con >50% de daño por Sigatoka.\n- Desbellote: Cortar la flor masculina tras formarse la última mano.\n- Embolse: Proteger racimo a las 2 semanas de floración.\n\n3. FERTILIZACIÓN SUGERIDA\n- Siembra: 150g Roca Fosfórica.\n- Crecimiento: Urea y DAP (Nitrógeno/Fósforo).\n- Producción: Cloruro de Potasio (KCl) para llenado.\n\n4. CONTROL DE PLAGAS\n- Sigatoka Negra: Control cultural (deshoje) y fungicidas sistémicos.\n- Picudo Negro: Trampas de feromona.',NULL),(4,'Solanum lycopersicum','Tomate Chonto',NULL,NULL,NULL,90,'🍅 **Manejo Intensivo:**\n- **Tutorado:** Indispensable para evitar contacto con suelo y enfermedades.\n- **Poda:** Eliminar chupones axilares semanalmente para dejar 1 o 2 tallos principales.\n- **Riego:** Goteo recomendado. Evitar mojar el follaje para prevenir Gota (Phytophthora).\n- **Nutrición:** Calcio es vital para evitar \"Culo negro\" (Podredumbre apical).\n- **Cosecha:** Inicia a los 70-80 días según clima.',NULL),(5,'Persea americana','Aguacate Hass',NULL,NULL,NULL,240,'🥑 **Vivero e Injertación:**\r\n- **Patrón:** Usar patrones criollos resistentes a Phytophthora.\r\n- **Injerto:** Realizar cuando el patrón tenga diámetro de lápiz (aprox. 4-6 meses).\r\n- **Riego:** Sensible al exceso de humedad. Evitar a toda costa el encharcamiento (Asfixia radicular).\r\n- **Sanidad:** Tratamientos preventivos con fungicidas para raíz antes del trasplante.\r\n- **Luz:** Adaptación gradual a luz solar directa antes de llevar a campo.','uploads/especies/1767683653_Aguacate_Hass.webp'),(6,'Coffea arabica','Café',NULL,NULL,NULL,240,'🌱 **Fase de Vivero (Almácigo):**\r\n- **Sustrato:** Mezcla 3:1 de tierra negra y materia orgánica (pulpa descompuesta). pH ideal 5.0 - 5.5.\r\n- **Riego:** Mantener humedad constante sin encharcar. Riego diario en zonas secas.\r\n- **Sombra:** Requiere 50-60% de sombra (sarán o polisombra) en los primeros 3 meses.\r\n- **Fertilización:** Aplicar 2g de DAP por bolsa al mes 2 y mes 4.\r\n- **Plagas:** Vigilar Minador de la hoja y Cercospora (Mancha de hierro).','uploads/especies/1767684507_Cafe.webp'),(7,'Zea mays','Maíz',NULL,NULL,NULL,120,'🌽 **Ciclo Corto:**\n- **Siembra:** Directa. Distancia recomendada 20-25 cm entre plantas.\n- **Requerimientos:** Altamente exigente en Nitrógeno (Urea) a los 15 y 45 días.\n- **Riego:** Crítico durante la floración y llenado de grano (R1-R3).\n- **Control:** Manejo agresivo de malezas en los primeros 40 días (período crítico de competencia).\n- **Plagas:** Gusano cogollero (Spodoptera frugiperda) requiere monitoreo semanal.',NULL),(8,'Aloe vera','Sábila (Aloe Vera)',NULL,NULL,NULL,0,'CUIDADOS DEL ALOE VERA\n\n1. LUZ Y UBICACIÓN\n- Pleno sol o luz indirecta muy brillante.\n- Evitar cambios bruscos de temperatura.\n\n2. RIEGO (Suculenta)\n- Riego escaso. Dejar secar completamente la tierra entre riegos.\n- Exceso de agua pudre las raíces rápidamente.\n- En invierno, reducir al mínimo.\n\n3. SUSTRATO\n- Muy bien drenado (tipo cactus). Mezcla de tierra con arena o perlita.\n\n4. COSECHA\n- Cortar las hojas basales (las más viejas y externas) cerca del tallo cuando estén carnosas.',NULL),(9,'Sansevieria trifasciata','Lengua de Suegra (Sansevieria)',NULL,NULL,NULL,0,'CUIDADOS DE LA SANSEVIERIA\n\n1. RESISTENCIA\n- Planta \"todoterreno\". Tolera poca luz y aire seco.\n- Ideal para dormitorios (purifica el aire de noche).\n\n2. RIEGO\n- Muy poco. Cada 15-20 días en verano, mensual en invierno.\n- No mojar el centro de la roseta de hojas.\n\n3. ABONO\n- Abono para plantas verdes o cactus una vez al mes en primavera/verano.\n- No requiere poda, solo retirar hojas secas.',NULL),(10,'Phalaenopsis spp.','Orquídea Mariposa',NULL,NULL,NULL,0,'CUIDADOS DE LA ORQUÍDEA PHALAENOPSIS\n\n1. LUZ\n- Luz filtrada o indirecta. Nunca sol directo (quema las hojas).\n- Raíces necesitan luz (usar macetas transparentes).\n\n2. RIEGO\n- Por inmersión: Sumergir la maceta en agua 10 min cuando las raíces se vean grises/plateadas.\n- Si están verdes, NO regar.\n- Evitar mojar el centro de las hojas (corona).\n\n3. SUSTRATO\n- Corteza de pino gruesa. No usar tierra normal.\n\n4. FLORACIÓN\n- Tras caer las flores, cortar la vara por encima del segundo nudo para estimular nueva floración.',NULL),(11,'Echeveria elegans','Suculenta Echeveria',NULL,NULL,NULL,0,'CUIDADOS DE SUCULENTAS (ECHEVERIA)\n\n1. LUZ\n- Necesita mucha luz, incluso sol directo de la mañana, para mantener su forma compacta.\n- Si se estira (etiolación), le falta luz.\n\n2. RIEGO \"REMOJO Y SECADO\"\n- Regar profundamente hasta que salga agua por el drenaje, luego no regar hasta que el sustrato esté totalmente seco.\n- No usar atomizador (rociador), el agua debe ir a la tierra, no a las hojas.\n\n3. PROBLEMAS COMUNES\n- Hojas arrugadas: Falta de agua.\n- Hojas amarillas/transparentes y blandas: Exceso de agua (pudrición).',NULL),(12,'Nephrolepis exaltata','Helecho de Boston',NULL,NULL,NULL,0,'CUIDADOS DEL HELECHO BOSTON\n\n1. AMBIENTE\n- Humedad alta es clave. Rociar las hojas frecuentemente o mantener en baño/cocina.\n- Luz indirecta suave. El sol directo quema las frondas.\n\n2. RIEGO\n- Mantener el sustrato ligeramente húmedo, pero no encharcado.\n- No dejar secar totalmente la tierra.\n\n3. FERTILIZACIÓN\n- Humus líquido o fertilizante para follaje cada 2-3 semanas en etapa de crecimiento.',NULL),(13,'Anthurium andraeanum','Anturio Rojo',NULL,NULL,NULL,0,'CUIDADOS DEL ANTURIO\r\n\r\n1. ILUMINACIÓN\r\n- Luz brillante indirecta para mantener la floración. Sin luz suficiente, no produce flores rojas.\r\n\r\n2. RIEGO Y HUMEDAD\r\n- Riego moderado cuando se seque la capa superficial.\r\n- Alta humedad ambiental (pulverizar hojas, no las flores).\r\n\r\n3. SUSTRATO\r\n- Suelto y aireado (mezcla de tierra, turba y perlita).\r\n\r\n4. LIMPIEZA\r\n- Limpiar el polvo de las hojas con un paño húmedo para mejorar la fotosíntesis.','uploads/especies/1767683864_Anturio_Rojo.webp'),(14,'Epipremnum aureum','Potos (Teléfono)',NULL,NULL,NULL,0,'CUIDADOS DEL POTOS\n\n1. VERSATILIDAD\n- Puede ser colgante o trepadora (con tutor).\n- Se adapta a luz baja, pero crece mejor con luz indirecta media.\n\n2. RIEGO\n- Dejar secar la tierra entre riegos. Es muy resistente a la sequía, pero sensible al encharcamiento.\n- Si las hojas se ponen lacias, necesita agua.\n\n3. PODA\n- Pinzar (cortar puntas) los tallos largos para que la planta se vuelva más frondosa desde la base.\n- Muy fácil de reproducir por esquejes en agua.',NULL),(15,'Mentha spicata','Menta / Hierbabuena',NULL,NULL,NULL,0,'CULTIVO DE MENTA/HIERBABUENA\r\n\r\n1. UBICACIÓN\r\n- Sombra parcial o sol suave.\r\n- Cuidado: Es invasiva (sus raíces se expanden rápido). Mejor cultivar en maceta individual.\r\n\r\n2. RIEGO\r\n- Exigente en agua. Mantener la tierra húmeda constantemente.\r\n- Si le falta agua, se marchita rápido (pero se recupera al regar).\r\n\r\n3. COSECHA\r\n- Cosechar las puntas de los tallos frecuentemente para estimular crecimiento lateral y evitar que florezca (la floración reduce el aroma).','uploads/especies/1767684427_Menta_Hierbabuena.webp'),(16,'Ocimum basilicum','Albahaca Genovesa',NULL,NULL,NULL,60,'CULTIVO DE ALBAHACA\r\n\r\n1. LUZ Y CALOR\r\n- Pleno sol (mínimo 6 horas).\r\n- Muy sensible al frío y heladas.\r\n\r\n2. RIEGO\r\n- Regular, en la base de la planta. Evitar mojar las hojas por la noche (hongos).\r\n\r\n3. PODA DE FLORES (IMPORTANTE)\r\n- Cortar los espigas florales apenas aparezcan. Si florece, las hojas se amargan y la planta envejece y muere.\r\n\r\n4. USOS\r\n- Cosechar hojas superiores para consumo fresco (pesto, ensaladas).','uploads/especies/1767683801_Albahaca_Genovesa.webp'),(17,'Salvia rosmarinus','Romero',NULL,NULL,NULL,0,'CULTIVO DE ROMERO\n\n1. SUELO Y LUZ\n- Pleno sol.\n- Suelo arenoso o pobre, pero con DRENAJE PERFECTO. No tolera humedad en raíces.\n\n2. RIEGO\n- Muy escaso. Es una planta mediterránea resistente a la sequía.\n- Dejar secar completamente antes de volver a regar.\n\n3. PODA\n- Podar las puntas después de la floración para mantener forma compacta y evitar que se vuelva leñoso y despoblado en la base.',NULL),(18,'Coriandrum sativum','Cilantro',NULL,NULL,NULL,45,'CULTIVO DE CILANTRO\n\n1. SIEMBRA\n- Directa (no tolera trasplante).\n- Sembrar escalonado (cada 2 semanas) para tener producción continua.\n\n2. CLIMA\n- Sol directo.\n- En climas muy calurosos, tiende a \"subirse\" (florecer) prematuramente. Mantener suelo fresco.\n\n3. RIEGO\n- Suelo húmedo pero no encharcado.\n\n4. COSECHA\n- Se puede cortar hojas externas o arrancar la planta entera a los 40-50 días.',NULL),(19,'Fragaria x ananassa','Fresa (Variedad Albión)',NULL,NULL,NULL,0,'CULTIVO DE FRESA\n\n1. SIEMBRA\n- Usar camellones altos para facilitar drenaje.\n- El cuello de la planta (corona) debe quedar a nivel del suelo, no enterrado.\n\n2. ACOLCHADO (Mulch)\n- Usar plástico o paja sobre la tierra para que el fruto no toque el suelo (evita pudrición).\n\n3. RIEGO\n- Riego localizado (goteo). El agua no debe tocar hojas ni frutos.\n- Frecuente pero ligero.\n\n4. PODA\n- Eliminar estolones (hijos) si se busca producción de fruta, para que la planta concentre energía.',NULL),(20,'Lactuca sativa','Lechuga Crespa',NULL,NULL,NULL,60,'CULTIVO DE LECHUGA\n\n1. CLIMA\n- Prefiere climas frescos. El calor excesivo la vuelve amarga y acelera la floración.\n\n2. RIEGO\n- Frecuente y ligero. Raíces muy superficiales.\n- El estrés hídrico afecta inmediatamente la calidad de la hoja.\n\n3. SIEMBRA\n- Semillero y trasplante a los 20-25 días.\n- Distancia: 25-30 cm entre plantas.\n\n4. COSECHA\n- Cosechar temprano en la mañana cuando las hojas están turgentes e hidratadas.',NULL),(21,'Capsicum annuum','Pimentón',NULL,NULL,NULL,100,'🌶️ **Guía Técnica:**\r\n- **Temperatura:** Óptima 20-25°C. Heladas causan muerte inmediata.\r\n- **Suelo:** Suelos profundos, pH 6.0-7.0. Sensible a salinidad.\r\n- **Riego:** Frecuente y ligero.\r\n- **Plagas:** Ácaros y Mosca Blanca son los vectores virales más peligrosos.\r\n- **Tutorado:** Requiere soporte (hilos o estacas) por el peso de los frutos.','uploads/especies/1767753853_Pimenton.webp'),(22,'Daucus carota','Zanahoria',NULL,NULL,NULL,90,'CULTIVO DE ZANAHORIA\n\n1. SUELO (CRÍTICO)\n- Suelo suelto, arenoso y profundo, SIN PIEDRAS.\n- Si el suelo es duro o tiene obstáculos, la zanahoria saldrá deforme o bifurcada.\n\n2. SIEMBRA\n- Directa. Semilla muy pequeña, mezclar con arena para distribuir mejor.\n\n3. RALEO (Entresaque)\n- Fundamental: Cuando tengan 3-4 cm, arrancar plantas sobrantes dejando 8-10 cm entre cada una. Si están muy juntas, no engrosan.\n\n4. APORQUE\n- Cubrir con tierra los \"hombros\" de la raíz si asoman, para que no se pongan verdes por el sol.',NULL),(23,'Allium fistulosum','Cebolla Larga / Junca',NULL,NULL,NULL,90,'CULTIVO DE CEBOLLA LARGA\n\n1. CLIMA\n- Se adapta bien a climas fríos y medios.\n\n2. SIEMBRA\n- Por \"esqueje\" (sembrar un tallo o \"hijo\" de otra planta).\n- Profundidad: Enterrar bien para asegurar blanqueamiento del tallo.\n\n3. APORQUE\n- Amontonar tierra alrededor de la base periódicamente. Esto estimula que el tallo crezca blanco, grueso y largo.\n\n4. SANIDAD\n- Controlar Thrips (manchas plateadas en hojas) y hongos en época de lluvia.',NULL),(25,'Theobroma cacao','Cacao',NULL,NULL,NULL,180,'🍫 **Etapa de Vivero:**\r\n- **Sombra:** Requiere sombra densa (70%) en etapa inicial, reducir al 40% antes del trasplante.\r\n- **Riego:** Diario. El estrés hídrico causa caída prematura de hojas.\r\n- **Fertilización:** Foliar rica en Zinc y Boro a partir del tercer mes.\r\n- **Plagas:** Monilia es la principal amenaza en fruto, pero en vivero cuidar de áfidos y trips en brotes tiernos.','uploads/especies/1767683998_Cacao.webp'),(26,'Citrus latifolia','Limón Tahití',NULL,NULL,NULL,300,'🍋 **Etapa Vivero:**\n- **Bolsa:** Usar bolsas de 40cm de profundidad para desarrollo radicular.\n- **Injerto:** Sobre patrón Volkarameriana o Sunki (según zona).\n- **Poda:** De formación para eliminar brotes bajos (chupadores) del patrón.\n- **Sanidad:** Minador de los cítricos daña las hojas nuevas, aplicar control en brotación.\n- **Riego:** Moderado.',NULL),(27,'Phaseolus vulgaris','Fríjol Cargamanto',NULL,NULL,NULL,110,'🌿 **Leguminosa Voluble:**\n- **Soporte:** Requiere tutorado o siembra asociada (ej. con Maíz).\n- **Suelo:** No tolera suelos ácidos (< 5.5 pH). Encalar si es necesario.\n- **Fijación N:** Aporta nitrógeno al suelo, ideal para rotación.\n- **Enfermedades:** Antracnosis es común en climas fríos y húmedos.\n- **Cosecha:** Vainas secas para grano o verdes para consumo fresco.',NULL),(28,'Manihot esculenta','Yuca',NULL,NULL,NULL,270,'🥔 **Cultivo Rústico:**\n- **Semilla:** Estacas (cangres) de 20cm de plantas sanas y vigorosas.\n- **Suelo:** Tolera suelos pobres y ácidos, pero requiere suelo suelto para engrosar raíces.\n- **Riego:** Muy resistente a sequía una vez establecida.\n- **Malezas:** Control estricto los primeros 3 meses.\n- **Cosecha:** Arrancar cuando las hojas inferiores amarillean (aprox. 9-10 meses).',NULL),(29,'papi','papayon',NULL,NULL,NULL,350,'asas','uploads/especies/1767682289_papaya.webp');
/*!40000 ALTER TABLE `especies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evento_sanitario`
--

DROP TABLE IF EXISTS `evento_sanitario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evento_sanitario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `lote_animal_id` int DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `descripcion` text,
  `costo_servicio` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lote_animal_id` (`lote_animal_id`),
  CONSTRAINT `evento_sanitario_ibfk_1` FOREIGN KEY (`lote_animal_id`) REFERENCES `lote_animal` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evento_sanitario`
--

LOCK TABLES `evento_sanitario` WRITE;
/*!40000 ALTER TABLE `evento_sanitario` DISABLE KEYS */;
/*!40000 ALTER TABLE `evento_sanitario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insumo`
--

DROP TABLE IF EXISTS `insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insumo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) DEFAULT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `unidad_medida_id` int DEFAULT NULL,
  `stock_minimo` float DEFAULT NULL,
  `cantidad_actual` float DEFAULT NULL,
  `costo_promedio` float DEFAULT NULL,
  `imagen_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unidad_medida_id` (`unidad_medida_id`),
  CONSTRAINT `insumo_ibfk_1` FOREIGN KEY (`unidad_medida_id`) REFERENCES `unidad_medida` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insumo`
--

LOCK TABLES `insumo` WRITE;
/*!40000 ALTER TABLE `insumo` DISABLE KEYS */;
INSERT INTO `insumo` VALUES (11,'INS-001','Triple 15','Insumo',7,10,5,5000,NULL),(12,'MAT-14','Matera Barro N14','Matera',8,5,200,3000,NULL),(13,'SUS-001','Tierra Negra Abonada','Sustrato',9,10,0,0,NULL),(14,'SUS-002','Cascarilla de Arroz (Cruda)','Sustrato',9,5,0,0,NULL),(15,'SUS-003','Cascarilla de Arroz (Quemada)','Sustrato',9,5,0,0,NULL),(16,'SUS-004','Turba Rubia (Peat Moss)','Sustrato',7,20,0,0,NULL),(17,'SUS-005','Humus de Lombriz Sólido','Sustrato',7,15,0,0,NULL),(18,'SUS-006','Perlita Agrícola','Sustrato',7,5,0,0,NULL),(19,'SUS-007','Fibra de Coco','Sustrato',9,5,0,0,NULL),(20,'FER-001','Triple 15 (15-15-15)','Fertilizante',7,50,0,0,NULL),(21,'FER-002','Urea Agrícola (46-0-0)','Fertilizante',7,25,0,0,NULL),(22,'FER-003','DAP (Fosfato Diamónico)','Fertilizante',7,25,0,0,NULL),(23,'FER-004','Osmocote 14-14-14 (Liberación Lenta)','Fertilizante',7,5,0,0,NULL),(24,'FER-005','Fertilizante Foliar Producción','Fertilizante',10,2,0,0,NULL),(25,'FER-006','Cal Agrícola (Dolomita)','Enmienda',7,20,10,15000,NULL),(26,'FIT-001','Aceite de Neem (Orgánico)','Insecticida',10,1,0,0,NULL),(27,'FIT-002','Jabón Potásico','Insecticida',10,2,0,0,NULL),(28,'FIT-003','Fungicida a base de Cobre','Fungicida',10,1,0,0,NULL),(29,'FIT-004','Glifosato (Herbicida)','Herbicida',10,5,0,0,NULL),(30,'MAC-001','Bolsa Vivero 1Kg (12x15)','Insumo',8,1000,1,10000,NULL),(31,'MAC-002','Bolsa Vivero 2Kg (17x23)','Insumo',8,500,0,0,NULL),(32,'MAC-003','Bolsa Vivero 5Kg (25x30)','Insumo',8,200,0,0,NULL),(33,'MAC-004','Bandeja Germinación 128 cavidades','Herramienta',8,10,0,0,NULL),(34,'MAC-005','Bandeja Germinación 200 cavidades','Herramienta',8,10,0,0,NULL),(35,'MAC-006','Matera P7 (Semillero cuadrada)','Insumo',8,500,0,0,NULL),(36,'VTA-001','Matera Barro N12 Clásica','Matera',8,20,0,0,NULL),(37,'VTA-002','Matera Barro N14 Clásica','Matera',8,20,0,0,NULL),(38,'VTA-003','Matera Plástica Premium Blanca N14','Matera',8,15,0,0,NULL),(39,'VTA-004','Sustrato Orquídeas Premium (Bolsa 1Kg)','Producto Comercial',8,10,0,0,NULL),(40,'HER-001','Tijera de Poda Mano','Herramienta',8,2,0,0,NULL),(41,'HER-002','Guantes Jardinería (Par)','Herramienta',8,5,1,1000,NULL),(42,'HER-003','Palita de Mano Metálica','Herramienta',8,3,0,0,NULL),(43,'5522','acha con palo metalico','Insumo',8,0,10,52000,NULL),(44,'785','marcopolo','Insumo',9,0,1,10000,NULL),(45,'555555','pala','Insumo',8,0,30,10000,'uploads/insumos/1768273327_pala-de-herramientas-manuales-3d.webp');
/*!40000 ALTER TABLE `insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insumos`
--

DROP TABLE IF EXISTS `insumos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insumos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `cantidad_actual` float DEFAULT NULL,
  `stock_minimo` float DEFAULT NULL,
  `costo_promedio` float DEFAULT NULL,
  `unidad_medida_id` int DEFAULT NULL,
  `imagen_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unidad_medida_id` (`unidad_medida_id`),
  CONSTRAINT `insumos_ibfk_1` FOREIGN KEY (`unidad_medida_id`) REFERENCES `unidades_medida` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insumos`
--

LOCK TABLES `insumos` WRITE;
/*!40000 ALTER TABLE `insumos` DISABLE KEYS */;
INSERT INTO `insumos` VALUES (1,'Abono','Fertilizante',1210,10,0,1,'uploads/insumos/1767745570_Abono.webp'),(3,'maceta para planta','Fertilizante',12,10,0,3,'uploads/insumos/1767745401_maceta_para_planta.webp'),(4,'Martillo','Herramienta',61,10,0,3,'uploads/insumos/1767745191_Martillo.webp'),(5,'Colino de Plátano','Semilla',3,10,0,3,'uploads/insumos/1767745112_Colino_de_Platano1.webp'),(7,'Mango','Semilla',100,10,0,3,NULL),(8,'maceta para planta grandes','Herramienta',50,10,0,3,NULL),(9,'semilla de cafe ','Semilla',200,10,0,3,NULL),(10,'fertilizante','Fertilizante',0,10,0,2,'uploads/insumos/1767690186_fertilizante.webp');
/*!40000 ALTER TABLE `insumos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kardex`
--

DROP TABLE IF EXISTS `kardex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kardex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fecha` datetime DEFAULT NULL,
  `tipo_movimiento` varchar(50) DEFAULT NULL,
  `cantidad` float NOT NULL,
  `costo_unitario` float DEFAULT NULL,
  `referencia` varchar(100) DEFAULT NULL,
  `insumo_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `insumo_id` (`insumo_id`),
  CONSTRAINT `kardex_ibfk_1` FOREIGN KEY (`insumo_id`) REFERENCES `insumos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kardex`
--

LOCK TABLES `kardex` WRITE;
/*!40000 ALTER TABLE `kardex` DISABLE KEYS */;
INSERT INTO `kardex` VALUES (1,'2025-12-18 12:21:28','Compra',50,120,'Pedido #OC-1766060151',1);
/*!40000 ALTER TABLE `kardex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `labor_campo`
--

DROP TABLE IF EXISTS `labor_campo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `labor_campo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lote_id` int DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `tipo_labor` varchar(50) DEFAULT NULL,
  `descripcion` text,
  PRIMARY KEY (`id`),
  KEY `lote_id` (`lote_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `labor_campo_ibfk_1` FOREIGN KEY (`lote_id`) REFERENCES `lote_produccion` (`id`),
  CONSTRAINT `labor_campo_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `labor_campo`
--

LOCK TABLES `labor_campo` WRITE;
/*!40000 ALTER TABLE `labor_campo` DISABLE KEYS */;
INSERT INTO `labor_campo` VALUES (13,6,1,'2026-01-08','Fertilización Inicial','Aplicación Triple 15'),(14,6,1,'2026-01-08','Deshierbe','se utilizan 6'),(15,9,1,'2026-01-13','Otro','se da palas a los trabajadores ');
/*!40000 ALTER TABLE `labor_campo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `labores_campo`
--

DROP TABLE IF EXISTS `labores_campo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `labores_campo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lote_id` int NOT NULL,
  `fecha` date DEFAULT NULL,
  `tipo_labor` varchar(50) DEFAULT NULL,
  `descripcion` text,
  `usuario_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lote_id` (`lote_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `labores_campo_ibfk_1` FOREIGN KEY (`lote_id`) REFERENCES `lotes_produccion` (`id`),
  CONSTRAINT `labores_campo_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `labores_campo`
--

LOCK TABLES `labores_campo` WRITE;
/*!40000 ALTER TABLE `labores_campo` DISABLE KEYS */;
INSERT INTO `labores_campo` VALUES (13,8,'2025-12-28','Riego','se riega lote',1),(14,8,'2025-12-29','Fertilizacion','aplique fertilizante 2 litros',1),(15,10,'2025-12-30','Riego','Se realiza el riego del tomate y se les aplica abono',1),(16,11,'2025-12-30','Otro','Se realiza la siembra de 10 plantas de cafe.',1);
/*!40000 ALTER TABLE `labores_campo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lote_animal`
--

DROP TABLE IF EXISTS `lote_animal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lote_animal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `especie` varchar(50) DEFAULT NULL,
  `raza` varchar(50) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `cantidad_inicial` int DEFAULT NULL,
  `cantidad_actual` int DEFAULT NULL,
  `peso_actual` float DEFAULT NULL,
  `sede_id` int DEFAULT NULL,
  `proposito` varchar(50) DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL,
  `costo_acumulado` float DEFAULT NULL,
  `imagen_url` varchar(255) DEFAULT NULL,
  `genero` varchar(20) DEFAULT NULL,
  `ubicacion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `sede_id` (`sede_id`),
  CONSTRAINT `lote_animal_ibfk_1` FOREIGN KEY (`sede_id`) REFERENCES `sede` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lote_animal`
--

LOCK TABLES `lote_animal` WRITE;
/*!40000 ALTER TABLE `lote_animal` DISABLE KEYS */;
INSERT INTO `lote_animal` VALUES (1,'1','vaca','Individual','Bovino','holstein','2024-01-12','2026-01-12',10,10,800,3,'Doble Propósito','Activo',15000000,NULL,NULL,NULL),(2,'2','chivo','Individual','Bovino','chi','2024-06-04','2026-01-12',20,20,60,3,'Carne','Activo',600000,'uploads/animales/1768250242_chivo.webp',NULL,NULL),(3,'3','vaca','Individual','Bovino','','2026-01-12','2026-01-12',1,1,8000,3,'Leche','Activo',15000000,'uploads/animales/1768250973_baca.webp',NULL,NULL),(4,'4','cerdo','Individual','Bovino','crdin','2025-02-12','2026-01-13',1,1,0,3,'Cría / Reproducción','Activo',0,'uploads/animales/1768272804_baca.webp','Hembra','Corral 1'),(5,'78987','gallinas','Individual','Avícola','ponedoras','2025-01-12','2026-01-13',1,1,0,4,'Doble Propósito','Activo',0,'uploads/animales/1768273753_gallina.webp','Hembra','Galpón 1');
/*!40000 ALTER TABLE `lote_animal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lote_insumo`
--

DROP TABLE IF EXISTS `lote_insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lote_insumo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `insumo_id` int NOT NULL,
  `pedido_id` int DEFAULT NULL,
  `fecha_compra` date DEFAULT NULL,
  `cantidad_inicial` float NOT NULL,
  `cantidad_actual` float NOT NULL,
  `costo_unitario` float NOT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `insumo_id` (`insumo_id`),
  KEY `pedido_id` (`pedido_id`),
  CONSTRAINT `lote_insumo_ibfk_1` FOREIGN KEY (`insumo_id`) REFERENCES `insumo` (`id`),
  CONSTRAINT `lote_insumo_ibfk_2` FOREIGN KEY (`pedido_id`) REFERENCES `pedido_compra` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lote_insumo`
--

LOCK TABLES `lote_insumo` WRITE;
/*!40000 ALTER TABLE `lote_insumo` DISABLE KEYS */;
INSERT INTO `lote_insumo` VALUES (28,11,21,'2023-01-12',50,0,4000,NULL),(29,11,22,'2023-02-02',50,3,5000,NULL),(30,12,23,'2023-01-15',100,100,3000,NULL),(31,41,24,'2026-01-08',1,1,1000,NULL),(32,25,24,'2026-01-08',10,10,15000,NULL),(33,12,24,'2026-01-08',100,100,3000,NULL),(34,11,28,'2026-01-10',2,2,5000,NULL),(35,43,28,'2026-01-10',10,10,52000,NULL),(36,44,28,'2026-01-10',1,1,10000,NULL),(37,30,28,'2026-01-10',1,1,10000,NULL),(38,45,30,'2026-01-13',40,30,10000,NULL);
/*!40000 ALTER TABLE `lote_insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lote_produccion`
--

DROP TABLE IF EXISTS `lote_produccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lote_produccion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo_lote` varchar(50) DEFAULT NULL,
  `especie_id` int DEFAULT NULL,
  `sede_id` int DEFAULT NULL,
  `fecha_siembra` date DEFAULT NULL,
  `fecha_cosecha_est` date DEFAULT NULL,
  `cantidad_sembrada` int DEFAULT NULL,
  `cantidad_actual` int DEFAULT NULL,
  `ubicacion` varchar(100) DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL,
  `costo_total` float DEFAULT NULL,
  `proposito` varchar(20) DEFAULT 'Venta Plantula',
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_lote` (`codigo_lote`),
  KEY `especie_id` (`especie_id`),
  KEY `sede_id` (`sede_id`),
  CONSTRAINT `lote_produccion_ibfk_1` FOREIGN KEY (`especie_id`) REFERENCES `especie` (`id`),
  CONSTRAINT `lote_produccion_ibfk_2` FOREIGN KEY (`sede_id`) REFERENCES `sede` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lote_produccion`
--

LOCK TABLES `lote_produccion` WRITE;
/*!40000 ALTER TABLE `lote_produccion` DISABLE KEYS */;
INSERT INTO `lote_produccion` VALUES (6,'L-TOM-001',18,3,'2023-01-20',NULL,1000,997,'Bloque A','En Crecimiento',279250,'Venta Plantula'),(7,'SMB-1767858562',23,4,'2026-01-08',NULL,50,50,'sector 1','En Crecimiento',0,'Venta Plantula'),(8,'SMB-1767934224',35,3,'2026-01-09',NULL,50,50,'sector 1','Disponible',0,'Venta Plantula'),(9,'SMB-1767940424',28,3,'2026-01-09',NULL,10,10,'sector 1','En Crecimiento',100000,'Produccion Fruto');
/*!40000 ALTER TABLE `lote_produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes`
--

DROP TABLE IF EXISTS `lotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lotes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo_unico` varchar(50) DEFAULT NULL,
  `especie_id` int NOT NULL,
  `fecha_siembra` date NOT NULL,
  `cantidad_inicial` int NOT NULL,
  `cantidad_actual` int NOT NULL,
  `fase_actual` varchar(50) DEFAULT NULL,
  `ubicacion` varchar(100) DEFAULT NULL,
  `costo_total_acumulado` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_unico` (`codigo_unico`),
  KEY `especie_id` (`especie_id`),
  CONSTRAINT `lotes_ibfk_1` FOREIGN KEY (`especie_id`) REFERENCES `especies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes`
--

LOCK TABLES `lotes` WRITE;
/*!40000 ALTER TABLE `lotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `lotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes_insumo`
--

DROP TABLE IF EXISTS `lotes_insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lotes_insumo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `insumo_id` int NOT NULL,
  `pedido_id` int DEFAULT NULL,
  `fecha_compra` date DEFAULT NULL,
  `cantidad_inicial` float NOT NULL,
  `cantidad_actual` float NOT NULL,
  `costo_unitario` float NOT NULL,
  `agotado` tinyint(1) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `insumo_id` (`insumo_id`),
  KEY `pedido_id` (`pedido_id`),
  CONSTRAINT `lotes_insumo_ibfk_1` FOREIGN KEY (`insumo_id`) REFERENCES `insumos` (`id`),
  CONSTRAINT `lotes_insumo_ibfk_2` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos_compra` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes_insumo`
--

LOCK TABLES `lotes_insumo` WRITE;
/*!40000 ALTER TABLE `lotes_insumo` DISABLE KEYS */;
INSERT INTO `lotes_insumo` VALUES (1,1,1,'2025-12-18',50,0,120,0,0),(2,1,4,'2025-12-23',10,0,1500,NULL,0),(3,1,2,'2025-12-23',200,10,100,NULL,1),(4,3,2,'2025-12-23',12,12,5000,NULL,1),(5,4,2,'2025-12-23',11,11,20000,NULL,1),(6,5,5,'2025-12-23',10,0,2000,NULL,0),(7,5,7,'2025-12-28',10,3,2400,NULL,1),(8,7,8,'2025-12-29',100,100,1000,NULL,1),(9,8,8,'2025-12-29',50,50,50000,NULL,1),(10,1,9,'2025-12-30',1000,1000,5000,NULL,1),(11,9,9,'2025-12-30',200,200,1000,NULL,1),(12,1,11,'2026-01-06',100,100,15000,NULL,1),(13,1,14,'2026-01-06',100,100,2500,NULL,1),(14,4,14,'2026-01-06',50,50,85000,NULL,1);
/*!40000 ALTER TABLE `lotes_insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes_produccion`
--

DROP TABLE IF EXISTS `lotes_produccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lotes_produccion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo_lote` varchar(50) NOT NULL,
  `especie_id` int NOT NULL,
  `fecha_siembra` date DEFAULT NULL,
  `fecha_estimada_venta` date DEFAULT NULL,
  `cantidad_sembrada` int NOT NULL,
  `cantidad_actual` int NOT NULL,
  `costo_insumos` float DEFAULT NULL,
  `costo_mano_obra` float DEFAULT NULL,
  `costo_total` float DEFAULT NULL,
  `ubicacion` varchar(100) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `sede_id` int DEFAULT NULL,
  `fecha_cosecha_estimada` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_lote` (`codigo_lote`),
  KEY `especie_id` (`especie_id`),
  KEY `fk_lote_sede` (`sede_id`),
  CONSTRAINT `fk_lote_sede` FOREIGN KEY (`sede_id`) REFERENCES `sedes` (`id`),
  CONSTRAINT `lotes_produccion_ibfk_1` FOREIGN KEY (`especie_id`) REFERENCES `especies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes_produccion`
--

LOCK TABLES `lotes_produccion` WRITE;
/*!40000 ALTER TABLE `lotes_produccion` DISABLE KEYS */;
INSERT INTO `lotes_produccion` VALUES (8,'LOTE-1766904926',1,'2025-12-28',NULL,4,4,1200,NULL,1200,'sector 2','En Crecimiento',NULL,NULL),(9,'LOTE-1766982353',2,'2025-12-29',NULL,50,50,0,NULL,0,'sector 3','En Crecimiento',NULL,NULL),(10,'LOTE-1767054771',4,'2025-12-30',NULL,50,50,2400,NULL,2400,'sector 1','En Crecimiento',NULL,NULL),(11,'LOTE-1767058786',6,'2025-12-30',NULL,10,10,35200,NULL,35200,'sector 4','En Crecimiento',NULL,NULL),(12,'LOTE-1767075582',17,'2025-12-30',NULL,10,10,0,NULL,0,'sector 1','En Crecimiento',NULL,NULL),(13,'SMB-1767667808',5,'2026-01-05',NULL,7,7,0,NULL,0,'Persea americana','En Crecimiento',1,NULL),(14,'SMB-1767668986',21,'2026-01-05',NULL,100,100,0,NULL,0,'Capsicum annuum','En Crecimiento',1,NULL),(15,'SMB-1767672663',15,'2026-01-06',NULL,20,20,0,NULL,0,'Sector 2','En Crecimiento',1,NULL),(16,'SMB-1767673639',1,'2026-01-06',NULL,500,500,0,NULL,0,'Sector 6','En Crecimiento',2,NULL),(17,'SMB-1767673950',6,'2026-01-06',NULL,22,22,0,NULL,0,'Sector 5','En Crecimiento',2,NULL);
/*!40000 ALTER TABLE `lotes_produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimiento_inventario`
--

DROP TABLE IF EXISTS `movimiento_inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movimiento_inventario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fecha` datetime DEFAULT NULL,
  `tipo_movimiento` varchar(50) DEFAULT NULL,
  `cantidad` float DEFAULT NULL,
  `costo_unitario` float DEFAULT NULL,
  `referencia` varchar(100) DEFAULT NULL,
  `insumo_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `insumo_id` (`insumo_id`),
  CONSTRAINT `movimiento_inventario_ibfk_1` FOREIGN KEY (`insumo_id`) REFERENCES `insumo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimiento_inventario`
--

LOCK TABLES `movimiento_inventario` WRITE;
/*!40000 ALTER TABLE `movimiento_inventario` DISABLE KEYS */;
INSERT INTO `movimiento_inventario` VALUES (23,'2026-01-08 03:50:44','Consumo Interno',60,4166.67,'Labor L-TOM-001',11),(24,'2026-01-08 04:49:42','Venta',1,5000,'Factura #FAC-1767846343',11),(25,'2026-01-08 07:24:44','Venta',30,5000,'Factura #FAC-1767857063',11),(26,'2026-01-08 08:27:50','Compra',1,1000,'Pedido #OC-1767845617',41),(27,'2026-01-08 08:27:50','Compra',10,15000,'Pedido #OC-1767845617',25),(28,'2026-01-08 08:27:50','Compra',100,3000,'Pedido #OC-1767845617',12),(29,'2026-01-10 08:18:44','Compra',2,5000,'Pedido #OC-1768027237',11),(30,'2026-01-10 08:18:44','Compra',10,52000,'Pedido #OC-1768027237',43),(31,'2026-01-10 08:18:44','Compra',1,10000,'Pedido #OC-1768027237',44),(32,'2026-01-10 08:18:45','Compra',1,10000,'Pedido #OC-1768027237',30),(33,'2026-01-13 03:00:16','Compra',40,10000,'Pedido #OC-1768034356',45);
/*!40000 ALTER TABLE `movimiento_inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimientos_inventario`
--

DROP TABLE IF EXISTS `movimientos_inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movimientos_inventario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fecha` datetime DEFAULT NULL,
  `tipo_movimiento` varchar(50) DEFAULT NULL,
  `cantidad` float DEFAULT NULL,
  `costo_unitario` float DEFAULT NULL,
  `insumo_id` int DEFAULT NULL,
  `referencia` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `insumo_id` (`insumo_id`),
  CONSTRAINT `movimientos_inventario_ibfk_1` FOREIGN KEY (`insumo_id`) REFERENCES `insumos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimientos_inventario`
--

LOCK TABLES `movimientos_inventario` WRITE;
/*!40000 ALTER TABLE `movimientos_inventario` DISABLE KEYS */;
INSERT INTO `movimientos_inventario` VALUES (1,'2025-12-23 22:45:22','Compra (Recepción)',10,1500,1,'Pedido #OC-1766215197'),(2,'2025-12-23 22:46:07','Compra (Recepción)',200,100,1,'Pedido #OC-1766061819'),(3,'2025-12-23 22:46:07','Compra (Recepción)',12,5000,3,'Pedido #OC-1766061819'),(4,'2025-12-23 22:46:07','Compra (Recepción)',11,20000,4,'Pedido #OC-1766061819'),(5,'2025-12-23 22:46:59','Compra (Recepción)',10,2000,5,'Pedido #OC-1766300936'),(6,'2025-12-28 03:07:19','Consumo Producción',-6,2000,5,'Labor Siembra en LOTE-1766891184'),(7,'2025-12-28 04:31:15','Consumo Producción',-10,120,1,'Labor Fertilizacion en LOTE-1766301613'),(8,'2025-12-28 05:09:37','Consumo Producción',-4,2000,5,'Labor Otro en LOTE-1766301613'),(9,'2025-12-28 06:26:20','Compra (Recepción)',10,2400,5,'Pedido #OC-1766903150'),(10,'2025-12-28 06:28:34','Consumo Producción',-7,2400,5,'Labor Otro en LOTE-1766903261'),(11,'2025-12-29 04:15:59','Consumo Producción',-10,120,1,'Labor Fertilizacion en LOTE-1766904926'),(12,'2025-12-29 04:21:31','Compra (Recepción)',100,1000,7,'Pedido #OC-1766982003'),(13,'2025-12-29 04:21:32','Compra (Recepción)',50,50000,8,'Pedido #OC-1766982003'),(14,'2025-12-30 01:27:06','Consumo Producción',-20,120,1,'Labor Riego en LOTE-1767054771'),(15,'2025-12-30 01:42:23','Consumo Producción',-210,167.619,1,'Labor Otro en LOTE-1767058786'),(16,'2025-12-30 01:45:47','Compra (Recepción)',1000,5000,1,'Pedido #OC-1767059034'),(17,'2025-12-30 01:45:47','Compra (Recepción)',200,1000,9,'Pedido #OC-1767059034'),(18,'2026-01-06 23:14:37','Compra (Recepción)',100,15000,1,'Pedido #OC-1767691285'),(19,'2026-01-06 23:14:58','Compra (Recepción)',100,2500,1,'Pedido #OC-1767741138'),(20,'2026-01-06 23:14:58','Compra (Recepción)',50,85000,4,'Pedido #OC-1767741138');
/*!40000 ALTER TABLE `movimientos_inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedido_compra`
--

DROP TABLE IF EXISTS `pedido_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedido_compra` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero_orden` varchar(50) DEFAULT NULL,
  `proveedor_id` int NOT NULL,
  `sede_id` int DEFAULT NULL,
  `fecha_solicitud` date DEFAULT NULL,
  `fecha_recepcion` date DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `total_estimado` float DEFAULT NULL,
  `fecha_entrega_estimada` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_orden` (`numero_orden`),
  KEY `proveedor_id` (`proveedor_id`),
  KEY `sede_id` (`sede_id`),
  CONSTRAINT `pedido_compra_ibfk_1` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `pedido_compra_ibfk_2` FOREIGN KEY (`sede_id`) REFERENCES `sede` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido_compra`
--

LOCK TABLES `pedido_compra` WRITE;
/*!40000 ALTER TABLE `pedido_compra` DISABLE KEYS */;
INSERT INTO `pedido_compra` VALUES (21,'OC-AUTO-001',2,4,'2023-01-10','2023-01-12','Recibido',200000,NULL),(22,'OC-AUTO-002',2,4,'2023-02-01','2023-02-02','Recibido',250000,NULL),(23,'OC-AUTO-003',3,4,'2023-01-15','2023-01-15','Recibido',300000,NULL),(24,'OC-1767845617',2,3,'2026-01-08','2026-01-08','Recibido',451000,NULL),(25,'OC-1767861104',2,NULL,'2026-01-08',NULL,'Borrador',5000,NULL),(26,'OC-1767862655',3,4,'2026-01-08',NULL,'Borrador',77000,NULL),(27,'OC-1767933189',2,3,'2026-01-09',NULL,'Borrador',110000,NULL),(28,'OC-1768027237',2,3,'2026-01-10','2026-01-10','Recibido',550000,'2026-01-17'),(29,'OC-1768033142',2,3,'2026-01-10',NULL,'Solicitado',85000,NULL),(30,'OC-1768034356',2,3,'2026-01-10','2026-01-13','Recibido',500000,'2026-01-14');
/*!40000 ALTER TABLE `pedido_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos_compra`
--

DROP TABLE IF EXISTS `pedidos_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedidos_compra` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero_orden` varchar(50) DEFAULT NULL,
  `proveedor_id` int NOT NULL,
  `fecha_solicitud` date DEFAULT NULL,
  `fecha_recepcion` date DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL,
  `total_estimado` float DEFAULT NULL,
  `sede_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_orden` (`numero_orden`),
  KEY `proveedor_id` (`proveedor_id`),
  CONSTRAINT `pedidos_compra_ibfk_1` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos_compra`
--

LOCK TABLES `pedidos_compra` WRITE;
/*!40000 ALTER TABLE `pedidos_compra` DISABLE KEYS */;
INSERT INTO `pedidos_compra` VALUES (1,'OC-1766060151',3,'2025-11-30','2025-12-18','Recibido',6000,NULL),(2,'OC-1766061819',3,'2025-12-18','2025-12-23','Recibido',300000,NULL),(3,'OC-1766212896',3,'2025-12-19',NULL,'Cancelado',0,NULL),(4,'OC-1766215197',3,'2025-12-20','2025-12-23','Recibido',15000,NULL),(5,'OC-1766300936',3,'2025-12-16','2025-12-23','Recibido',20000,NULL),(6,'OC-1766540526',3,'2025-12-24',NULL,'Cancelado',0,NULL),(7,'OC-1766903150',3,'2025-12-28','2025-12-28','Recibido',24000,NULL),(8,'OC-1766982003',3,'2025-12-29','2025-12-29','Recibido',2600000,NULL),(9,'OC-1767059034',3,'2025-12-30','2025-12-30','Recibido',5200000,NULL),(10,'OC-1767691213',3,'2026-01-06',NULL,'Cancelado',0,NULL),(11,'OC-1767691285',3,'2026-01-06','2026-01-06','Recibido',1500000,2),(12,'OC-1767692598',3,'2026-01-06',NULL,'Cancelado',0,NULL),(13,'OC-1767692989',3,'2026-01-06',NULL,'Borrador',250000,2),(14,'OC-1767741138',3,'2026-01-06','2026-01-06','Recibido',4500000,1),(15,'OC-1767741443',3,'2026-01-06',NULL,'Borrador',0,NULL),(16,'OC-1767744535',3,'2026-01-06',NULL,'Borrador',0,NULL),(17,'OC-1767744539',3,'2026-01-06',NULL,'Borrador',0,NULL),(18,'OC-1767747200',3,'2026-01-06',NULL,'Borrador',0,NULL),(19,'OC-1767747211',3,'2026-01-06',NULL,'Borrador',0,NULL),(20,'OC-1767754382',3,'2026-01-06',NULL,'Borrador',0,NULL);
/*!40000 ALTER TABLE `pedidos_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produccion_animal`
--

DROP TABLE IF EXISTS `produccion_animal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produccion_animal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fecha` datetime DEFAULT NULL,
  `lote_animal_id` int DEFAULT NULL,
  `producto_id` int DEFAULT NULL,
  `cantidad` float DEFAULT NULL,
  `observaciones` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lote_animal_id` (`lote_animal_id`),
  KEY `producto_id` (`producto_id`),
  CONSTRAINT `produccion_animal_ibfk_1` FOREIGN KEY (`lote_animal_id`) REFERENCES `lote_animal` (`id`),
  CONSTRAINT `produccion_animal_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `insumo` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produccion_animal`
--

LOCK TABLES `produccion_animal` WRITE;
/*!40000 ALTER TABLE `produccion_animal` DISABLE KEYS */;
/*!40000 ALTER TABLE `produccion_animal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sku` varchar(50) DEFAULT NULL,
  `nombre` varchar(100) NOT NULL,
  `precio_base` float NOT NULL,
  `stock_disponible` int DEFAULT NULL,
  `publicado_web` tinyint(1) DEFAULT NULL,
  `descripcion_web` text,
  `imagen_principal` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku` (`sku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `razon_social` varchar(100) NOT NULL,
  `nit_rut` varchar(20) NOT NULL,
  `contacto_nombre` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
INSERT INTO `proveedor` VALUES (2,'AgroInsumos Ltda','900100200','Carlos','3001234567',NULL,NULL),(3,'Plasticos y Materas','800900100','Ana','3109876543',NULL,NULL);
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `razon_social` varchar(150) NOT NULL,
  `nit_rut` varchar(50) DEFAULT NULL,
  `contacto_nombre` varchar(100) DEFAULT NULL,
  `telefono` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nit_rut` (`nit_rut`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES (3,'Dilan Sneider','123','Sneider','3159529722','kpucho01@hotmail.com','Piedecuesta');
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rol`
--

DROP TABLE IF EXISTS `rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rol` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol`
--

LOCK TABLES `rol` WRITE;
/*!40000 ALTER TABLE `rol` DISABLE KEYS */;
INSERT INTO `rol` VALUES (1,'Administrador'),(3,'Agrónomo'),(2,'Trabajador'),(4,'Vendedor');
/*!40000 ALTER TABLE `rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador'),(3,'Agrónomo'),(2,'Trabajador'),(4,'Vendedor');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sede`
--

DROP TABLE IF EXISTS `sede`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sede` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `ubicacion_geo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sede`
--

LOCK TABLES `sede` WRITE;
/*!40000 ALTER TABLE `sede` DISABLE KEYS */;
INSERT INTO `sede` VALUES (3,'Finca El Paraíso','Finca','Vereda La Fuente'),(4,'Bodega Central','Bodega','Centro');
/*!40000 ALTER TABLE `sede` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sedes`
--

DROP TABLE IF EXISTS `sedes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sedes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `ubicacion_geo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sedes`
--

LOCK TABLES `sedes` WRITE;
/*!40000 ALTER TABLE `sedes` DISABLE KEYS */;
INSERT INTO `sedes` VALUES (1,'El rodeo','Finca','La 45 '),(2,'la inmaculada','Finca','km 53');
/*!40000 ALTER TABLE `sedes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tareas_lote`
--

DROP TABLE IF EXISTS `tareas_lote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tareas_lote` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lote_id` int NOT NULL,
  `usuario_id` int DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `tipo_labor_id` int DEFAULT NULL,
  `insumo_aplicado_id` int DEFAULT NULL,
  `cantidad_insumo` float DEFAULT NULL,
  `observaciones` text,
  PRIMARY KEY (`id`),
  KEY `lote_id` (`lote_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `tipo_labor_id` (`tipo_labor_id`),
  KEY `insumo_aplicado_id` (`insumo_aplicado_id`),
  CONSTRAINT `tareas_lote_ibfk_1` FOREIGN KEY (`lote_id`) REFERENCES `lotes` (`id`),
  CONSTRAINT `tareas_lote_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `tareas_lote_ibfk_3` FOREIGN KEY (`tipo_labor_id`) REFERENCES `tipos_labor` (`id`),
  CONSTRAINT `tareas_lote_ibfk_4` FOREIGN KEY (`insumo_aplicado_id`) REFERENCES `insumos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tareas_lote`
--

LOCK TABLES `tareas_lote` WRITE;
/*!40000 ALTER TABLE `tareas_lote` DISABLE KEYS */;
/*!40000 ALTER TABLE `tareas_lote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_labor`
--

DROP TABLE IF EXISTS `tipos_labor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipos_labor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_labor`
--

LOCK TABLES `tipos_labor` WRITE;
/*!40000 ALTER TABLE `tipos_labor` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipos_labor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unidad_medida`
--

DROP TABLE IF EXISTS `unidad_medida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unidad_medida` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `abreviatura` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidad_medida`
--

LOCK TABLES `unidad_medida` WRITE;
/*!40000 ALTER TABLE `unidad_medida` DISABLE KEYS */;
INSERT INTO `unidad_medida` VALUES (7,'Kilogramo','Kg'),(8,'Unidad','Und'),(9,'Bulto','Bto'),(10,'Litro','L'),(11,'Metro Cúbico','m3'),(12,'Gramo','g'),(13,'Mililitro','ml'),(14,'Rollo','Rollo');
/*!40000 ALTER TABLE `unidad_medida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unidades_medida`
--

DROP TABLE IF EXISTS `unidades_medida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unidades_medida` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `abreviatura` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidades_medida`
--

LOCK TABLES `unidades_medida` WRITE;
/*!40000 ALTER TABLE `unidades_medida` DISABLE KEYS */;
INSERT INTO `unidades_medida` VALUES (1,'Kilogramo','kg'),(2,'Litro','L'),(3,'Unidad','ud'),(4,'Saco 50kg','saco');
/*!40000 ALTER TABLE `unidades_medida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `rol_id` int DEFAULT NULL,
  `fecha_registro` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `rol_id` (`rol_id`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'Jhosneider','kpucho01@hotmail.com','scrypt:32768:8:1$93bLy0mdAPD5QRn9$911040c96d97c34febf83732efc0412247238ea64a306f6f391b2219ae2cfe6e102542ae78377cc14248bdf9465c7e61b75005f6be4d4ccd99b5b060c713a77d','3159392757',1,'2026-01-07');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(100) NOT NULL,
  `documento_identidad` varchar(20) DEFAULT NULL,
  `email` varchar(120) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `fecha_registro` datetime DEFAULT NULL,
  `rol_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `rol_id` (`rol_id`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Jhosneider',NULL,'kpucho01@hotmail.com','scrypt:32768:8:1$bWl1cE3vhXfJLMKe$3ee2396b1f35c5e9f6d2afdd5d7f779cded5186e29dd3f7f99784ac325a2f89592c17cc6d64c16d9df83f8edc6f75bc2cd8a1fc5d29b6626e009a0eb19e1f7dc','3159392757','Activo','2025-12-17 06:35:09',1);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venta`
--

DROP TABLE IF EXISTS `venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero_factura` varchar(50) DEFAULT NULL,
  `cliente_id` int DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `total` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_factura` (`numero_factura`),
  KEY `cliente_id` (`cliente_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `venta_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`),
  CONSTRAINT `venta_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venta`
--

LOCK TABLES `venta` WRITE;
/*!40000 ALTER TABLE `venta` DISABLE KEYS */;
INSERT INTO `venta` VALUES (12,'FAC-1767844486',3,1,'2026-01-08 03:54:46','Borrador',13650),(13,'FAC-1767845628',3,1,'2026-01-08 04:13:48','Anulada',63728),(14,'FAC-1767846343',4,1,'2026-01-08 04:25:44','Finalizada',7475),(15,'FAC-1767857063',3,1,'2026-01-08 07:24:23','Finalizada',195000),(16,'FAC-1767933346',3,1,'2026-01-09 04:35:46','Borrador',0);
/*!40000 ALTER TABLE `venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventas`
--

DROP TABLE IF EXISTS `ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero_factura` varchar(50) NOT NULL,
  `cliente_id` int NOT NULL,
  `fecha` datetime DEFAULT NULL,
  `total` float DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_factura` (`numero_factura`),
  KEY `cliente_id` (`cliente_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventas`
--

LOCK TABLES `ventas` WRITE;
/*!40000 ALTER TABLE `ventas` DISABLE KEYS */;
INSERT INTO `ventas` VALUES (1,'FAC-1766545682',1,'2025-12-24 03:08:02',0,'Borrador',1),(3,'FAC-1766554872',2,'2025-12-24 05:41:12',0,'Borrador',1),(5,'FAC-1766555700',2,'2025-12-24 05:55:00',0,'Borrador',1),(6,'FAC-1767493825',2,'2026-01-04 02:30:26',0,'Borrador',1),(7,'FAC-1767671019',2,'2026-01-06 03:43:39',0,'Borrador',1),(8,'FAC-1767687743',1,'2026-01-06 08:22:23',0,'Borrador',1),(9,'FAC-1767687853',2,'2026-01-06 08:24:14',0,'Borrador',1),(10,'FAC-1767691274',2,'2026-01-06 09:21:14',0,'Borrador',1),(11,'FAC-1767737288',2,'2026-01-06 22:08:09',0,'Borrador',1),(12,'FAC-1767741341',2,'2026-01-06 23:15:41',0,'Borrador',1),(13,'FAC-1767755423',2,'2026-01-07 03:10:23',1500,'Borrador',1);
/*!40000 ALTER TABLE `ventas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-12 21:29:12
