import os
from app import create_app, db
from sqlalchemy import text

# Inicializamos la app para poder acceder a la base de datos
app = create_app()

def actualizar_base_datos():
    print("\n--- 🛠️  INICIANDO ACTUALIZACIÓN DE BASE DE DATOS ---")
    
    with app.app_context():
        # PASO 1: Crear tablas nuevas (como la tabla 'sedes')
        print("1. Creando tablas nuevas (si faltan)...")
        try:
            db.create_all()
            print("   ✅ Tablas sincronizadas.")
        except Exception as e:
            print(f"   ❌ Error en create_all: {e}")

        # PASO 2: Agregar la columna 'sede_id' a 'lotes_produccion'
        print("2. Verificando columna 'sede_id' en 'lotes_produccion'...")
        try:
            with db.engine.connect() as conn:
                # Verificamos si la columna ya existe para no romper nada
                check_query = text("""
                    SELECT count(*) 
                    FROM information_schema.COLUMNS 
                    WHERE TABLE_SCHEMA = DATABASE() 
                    AND TABLE_NAME = 'lotes_produccion' 
                    AND COLUMN_NAME = 'sede_id'
                """)
                result = conn.execute(check_query)
                existe = result.scalar() > 0
                
                if not existe:
                    print("   ... La columna no existe. Agregándola ahora...")
                    # Agregamos la columna
                    conn.execute(text("ALTER TABLE lotes_produccion ADD COLUMN sede_id INT NULL"))
                    # Agregamos la relación (Foreign Key) con la tabla sedes
                    conn.execute(text("ALTER TABLE lotes_produccion ADD CONSTRAINT fk_lote_sede FOREIGN KEY (sede_id) REFERENCES sedes(id)"))
                    conn.commit()
                    print("   ✅ ¡Éxito! Columna 'sede_id' agregada y vinculada.")
                else:
                    print("   ℹ️  La columna ya existe. Todo está correcto.")
                    
        except Exception as e:
            print(f"   ❌ Error al modificar la tabla: {e}")
            print("      Asegúrate de que tu servidor MySQL esté corriendo.")

    print("\n--- PROCESO FINALIZADO. YA PUEDES EJECUTAR 'run.py' ---")

if __name__ == "__main__":
    actualizar_base_datos()